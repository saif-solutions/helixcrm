const fs = require('fs');
const path = require('path');

const bridgePath = path.join(__dirname, 'apps/api/src/modules/auth/adapters/PrismaTokenRepositoryBridge.ts');
let content = fs.readFileSync(bridgePath, 'utf8');

// The issue is that we inserted logging BEFORE the variable declaration
// We need to move the logging AFTER the database query

// Find and fix the findRefreshToken method
const lines = content.split('\n');
let fixedContent = '';
let i = 0;

while (i < lines.length) {
  // Look for the problematic section
  if (lines[i].includes('async findRefreshToken(tokenId: string): Promise<RefreshToken | null>')) {
    // Copy method signature
    fixedContent += lines[i] + '\n';
    i++;
    
    // Copy opening brace and debug logging
    while (i < lines.length && !lines[i].includes('const user = await this.prisma.user.findFirst')) {
      fixedContent += lines[i] + '\n';
      i++;
    }
    
    // Now we're at the database query line
    // Copy the query line
    fixedContent += lines[i] + '\n';
    i++;
    
    // Skip the incorrectly placed logging (lines 103-109 in error)
    // Skip until we find the closing brace of findFirst call
    while (i < lines.length && !lines[i].trim().startsWith('});')) {
      i++; // Skip the malformed logging
    }
    
    // Now add CORRECT logging AFTER the query
    fixedContent += `    
    this.logger.debug('[BRIDGE-DEBUG] Database query result', {
      userFound: !!user,
      userId: user?.id,
      dbJti: user?.refreshTokenVersion,
      dbJtiPrefix: user?.refreshTokenVersion?.substring(0, 20),
      hashExists: !!user?.refreshTokenHash,
    });\n`;
    
    // Copy the rest of the method
    while (i < lines.length && !lines[i].includes('async invalidateRefreshToken')) {
      fixedContent += lines[i] + '\n';
      i++;
    }
  } else {
    fixedContent += lines[i] + '\n';
    i++;
  }
}

// Write fixed content
fs.writeFileSync(bridgePath, fixedContent);
console.log('✅ Fixed Bridge syntax errors');
console.log('Logging now correctly placed AFTER database query');
