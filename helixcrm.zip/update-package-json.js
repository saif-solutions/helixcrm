const fs = require('fs');
const path = require('path');

const packagePath = path.join(__dirname, 'apps/api/package.json');
const packageJson = JSON.parse(fs.readFileSync(packagePath, 'utf8'));

// Add test scripts
packageJson.scripts = {
  ...packageJson.scripts,
  "test:unit": "jest apps/api/test/unit --passWithNoTests",
  "test:integration": "jest apps/api/test/integration --passWithNoTests --runInBand",
  "test:contracts": "vitest run tests/contracts --passWithNoTests",
  "test:security": "vitest run tests/security --passWithNoTests",
  "test:all": "npm run test:unit && npm run test:integration && npm run test:contracts && npm run test:security",
  "test": "npm run test:unit"
};

// Add Jest configuration if not present
if (!packageJson.jest) {
  packageJson.jest = {
    "moduleFileExtensions": ["js", "json", "ts"],
    "rootDir": ".",
    "testRegex": ".*\\.spec\\.ts$",
    "transform": {
      "^.+\\.(t|j)s$": "ts-jest"
    },
    "collectCoverageFrom": ["**/*.(t|j)s"],
    "coverageDirectory": "../coverage",
    "testEnvironment": "node"
  };
}

// Write back
fs.writeFileSync(packagePath, JSON.stringify(packageJson, null, 2));
console.log('✅ Updated package.json with test scripts');
