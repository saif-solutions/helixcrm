const { PrismaClient } = require('@prisma/client');

async function fixLowercaseEnums() {
  const prisma = new PrismaClient();
  
  console.log('��� SEARCHING FOR LOWERCASE ENUM VALUES ���');
  console.log('='.repeat(50));
  
  try {
    // 1. First, find ALL audit logs to see what we have
    console.log('\n1️⃣ Counting total audit logs...');
    const totalCount = await prisma.auditLog.count();
    console.log(`��� Total audit logs: ${totalCount}`);
    
    if (totalCount === 0) {
      console.log('✅ No audit logs to fix');
      return;
    }
    
    // 2. Find lowercase values using more specific queries
    console.log('\n2️⃣ Searching for lowercase values...');
    
    const lowercaseResults = await prisma.$queryRaw`
      SELECT 
        'actorType' as column_name,
        "actorType" as value,
        COUNT(*) as count
      FROM audit_logs 
      WHERE "actorType" IN ('user', 'system')
      GROUP BY "actorType"
      
      UNION ALL
      
      SELECT 
        'action' as column_name,
        action as value,
        COUNT(*) as count
      FROM audit_logs 
      WHERE LOWER(action) = action
        AND action NOT IN (
          SELECT unnest(enum_range(NULL::"AuditAction"::text))
        )
      GROUP BY action
      
      UNION ALL
      
      SELECT 
        'entityType' as column_name,
        "entityType" as value,
        COUNT(*) as count
      FROM audit_logs 
      WHERE LOWER("entityType") = "entityType"
        AND "entityType" NOT IN (
          SELECT unnest(enum_range(NULL::"AuditEntityType"::text))
        )
      GROUP BY "entityType"
      
      UNION ALL
      
      SELECT 
        'severity' as column_name,
        severity as value,
        COUNT(*) as count
      FROM audit_logs 
      WHERE LOWER(severity) = severity
        AND severity NOT IN (
          SELECT unnest(enum_range(NULL::"AuditSeverity"::text))
        )
      GROUP BY severity
      
      ORDER BY column_name, count DESC
    `;
    
    console.log('��� Found lowercase values:');
    if (lowercaseResults.length === 0) {
      console.log('✅ No lowercase values found!');
    } else {
      console.table(lowercaseResults);
      
      // 3. Get valid ENUM values from database
      console.log('\n3️⃣ Getting valid ENUM values from database...');
      const validActorTypes = await prisma.$queryRaw`
        SELECT unnest(enum_range(NULL::"ActorType")) as value
      `;
      const validActions = await prisma.$queryRaw`
        SELECT unnest(enum_range(NULL::"AuditAction")) as value
      `;
      const validEntityTypes = await prisma.$queryRaw`
        SELECT unnest(enum_range(NULL::"AuditEntityType")) as value
      `;
      const validSeverities = await prisma.$queryRaw`
        SELECT unnest(enum_range(NULL::"AuditSeverity")) as value
      `;
      
      console.log('✅ Valid ActorType values:', validActorTypes.map(v => v.value));
      console.log('✅ Valid AuditAction values:', validActions.map(v => v.value));
      console.log('✅ Valid AuditEntityType values:', validEntityTypes.map(v => v.value));
      console.log('✅ Valid AuditSeverity values:', validSeverities.map(v => v.value));
      
      // 4. Fix the lowercase values
      console.log('\n4️⃣ Fixing lowercase values...');
      
      // Fix actorType
      const actorTypeLowercase = lowercaseResults.filter(r => r.column_name === 'actorType');
      if (actorTypeLowercase.length > 0) {
        console.log('��� Fixing actorType...');
        for (const row of actorTypeLowercase) {
          const uppercaseValue = row.value.toUpperCase();
          if (validActorTypes.some(v => v.value === uppercaseValue)) {
            await prisma.$executeRaw`
              UPDATE audit_logs 
              SET "actorType" = ${uppercaseValue}::"ActorType"
              WHERE "actorType" = ${row.value}
            `;
            console.log(`   Converted ${row.count} records from '${row.value}' to '${uppercaseValue}'`);
          } else {
            console.log(`   ⚠️  '${uppercaseValue}' is not a valid ActorType, using 'USER'`);
            await prisma.$executeRaw`
              UPDATE audit_logs 
              SET "actorType" = 'USER'::"ActorType"
              WHERE "actorType" = ${row.value}
            `;
          }
        }
      }
      
      // Fix action
      const actionLowercase = lowercaseResults.filter(r => r.column_name === 'action');
      if (actionLowercase.length > 0) {
        console.log('��� Fixing action...');
        for (const row of actionLowercase) {
          const uppercaseValue = row.value.toUpperCase();
          if (validActions.some(v => v.value === uppercaseValue)) {
            await prisma.$executeRaw`
              UPDATE audit_logs 
              SET action = ${uppercaseValue}::"AuditAction"
              WHERE action = ${row.value}
            `;
            console.log(`   Converted ${row.count} records from '${row.value}' to '${uppercaseValue}'`);
          } else {
            console.log(`   ⚠️  '${uppercaseValue}' is not a valid AuditAction, using 'SYSTEM_ERROR'`);
            await prisma.$executeRaw`
              UPDATE audit_logs 
              SET action = 'SYSTEM_ERROR'::"AuditAction"
              WHERE action = ${row.value}
            `;
          }
        }
      }
      
      // Fix entityType
      const entityTypeLowercase = lowercaseResults.filter(r => r.column_name === 'entityType');
      if (entityTypeLowercase.length > 0) {
        console.log('��� Fixing entityType...');
        for (const row of entityTypeLowercase) {
          const uppercaseValue = row.value.toUpperCase();
          if (validEntityTypes.some(v => v.value === uppercaseValue)) {
            await prisma.$executeRaw`
              UPDATE audit_logs 
              SET "entityType" = ${uppercaseValue}::"AuditEntityType"
              WHERE "entityType" = ${row.value}
            `;
            console.log(`   Converted ${row.count} records from '${row.value}' to '${uppercaseValue}'`);
          } else {
            console.log(`   ⚠️  '${uppercaseValue}' is not a valid AuditEntityType, using 'SYSTEM'`);
            await prisma.$executeRaw`
              UPDATE audit_logs 
              SET "entityType" = 'SYSTEM'::"AuditEntityType"
              WHERE "entityType" = ${row.value}
            `;
          }
        }
      }
      
      // Fix severity
      const severityLowercase = lowercaseResults.filter(r => r.column_name === 'severity');
      if (severityLowercase.length > 0) {
        console.log('��� Fixing severity...');
        for (const row of severityLowercase) {
          const uppercaseValue = row.value.toUpperCase();
          if (validSeverities.some(v => v.value === uppercaseValue)) {
            await prisma.$executeRaw`
              UPDATE audit_logs 
              SET severity = ${uppercaseValue}::"AuditSeverity"
              WHERE severity = ${row.value}
            `;
            console.log(`   Converted ${row.count} records from '${row.value}' to '${uppercaseValue}'`);
          } else {
            console.log(`   ⚠️  '${uppercaseValue}' is not a valid AuditSeverity, using 'LOW'`);
            await prisma.$executeRaw`
              UPDATE audit_logs 
              SET severity = 'LOW'::"AuditSeverity"
              WHERE severity = ${row.value}
            `;
          }
        }
      }
      
      console.log('✅ All lowercase values fixed!');
    }
    
    // 5. Final verification
    console.log('\n5️⃣ Final verification...');
    const finalLowercaseCheck = await prisma.$queryRaw`
      SELECT 
        COUNT(CASE WHEN "actorType" IN ('user', 'system') THEN 1 END) as lowercase_actor,
        COUNT(CASE WHEN LOWER(action) = action AND action NOT IN (
          SELECT unnest(enum_range(NULL::"AuditAction"::text))
        ) THEN 1 END) as lowercase_action,
        COUNT(CASE WHEN LOWER("entityType") = "entityType" AND "entityType" NOT IN (
          SELECT unnest(enum_range(NULL::"AuditEntityType"::text))
        ) THEN 1 END) as lowercase_entity,
        COUNT(CASE WHEN LOWER(severity) = severity AND severity NOT IN (
          SELECT unnest(enum_range(NULL::"AuditSeverity"::text))
        ) THEN 1 END) as lowercase_severity
      FROM audit_logs
    `;
    
    const hasIssues = Object.values(finalLowercaseCheck[0]).some(count => count > 0);
    
    if (!hasIssues) {
      console.log('✅ Database is clean - no lowercase enum values!');
      console.log('��� ENUM FIX COMPLETED SUCCESSFULLY! ���');
    } else {
      console.error('❌ Still found lowercase values:', finalLowercaseCheck[0]);
      console.error('   This indicates deeper schema issues.');
    }
    
    // 6. Test that we can now query without errors
    console.log('\n6️⃣ Testing query after fix...');
    try {
      const testQuery = await prisma.$queryRaw`
        SELECT 
          "actorType",
          COUNT(*) as count
        FROM audit_logs
        GROUP BY "actorType"
        ORDER BY count DESC
      `;
      console.log('✅ Query succeeded! Results:', testQuery);
    } catch (queryError) {
      console.error('❌ Query still failing:', queryError.message);
    }
    
  } catch (error) {
    console.error('\n❌ FIX FAILED:', error.message);
    console.error('Full error:', error);
  } finally {
    await prisma.$disconnect();
    console.log('\n��� Prisma disconnected');
  }
}

fixLowercaseEnums();
