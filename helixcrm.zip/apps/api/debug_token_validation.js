const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function debugTokenValidation() {
  console.log('��� DEBUGGING REFRESH TOKEN VALIDATION\n');
  
  try {
    const email = 'test3@example.com';
    
    // Get current user state
    const user = await prisma.user.findUnique({
      where: { email },
      select: { 
        id: true,
        email: true,
        refreshTokenVersion: true,
        refreshTokenHash: true,
        refreshTokenIssuedAt: true,
        tokenVersion: true
      }
    });
    
    if (!user) {
      console.log('User not found');
      return;
    }
    
    console.log('Current user state:');
    console.log(`  User ID: ${user.id}`);
    console.log(`  Email: ${user.email}`);
    console.log(`  JTI in DB: ${user.refreshTokenVersion?.substring(0, 30)}...`);
    console.log(`  JTI length: ${user.refreshTokenVersion?.length}`);
    console.log(`  Hash exists: ${!!user.refreshTokenHash}`);
    console.log(`  Hash length: ${user.refreshTokenHash?.length}`);
    console.log(`  Hash prefix: ${user.refreshTokenHash?.substring(0, 30)}...`);
    console.log(`  Token version: ${user.tokenVersion}`);
    console.log(`  Issued at: ${user.refreshTokenIssuedAt?.toISOString()}`);
    
    // Check if the JTI looks like a valid SHA256 hash
    const isJtiValid = /^[a-f0-9]{64}$/i.test(user.refreshTokenVersion || '');
    console.log(`\nJTI validation: ${isJtiValid ? '✅ Valid 64-char hex' : '❌ Invalid format'}`);
    
    // Check if hash looks like bcrypt
    const isBcryptHash = user.refreshTokenHash?.startsWith('$2b$') || 
                         user.refreshTokenHash?.startsWith('$2a$') ||
                         user.refreshTokenHash?.startsWith('$2y$');
    console.log(`Hash format: ${isBcryptHash ? '✅ Looks like bcrypt' : '❌ Not bcrypt format'}`);
    
    // Let me also check what auth-core is doing
    console.log('\n��� ANALYSIS: Possible issues:');
    console.log('1. Bridge.findRefreshToken() may not find token by JTI');
    console.log('2. Bridge may be looking for token in wrong format');
    console.log('3. Token hash comparison may be failing');
    
    // Check if there are any other users with similar issues
    console.log('\n��� Checking other users...');
    const allUsers = await prisma.user.findMany({
      where: {
        refreshTokenVersion: { not: null }
      },
      select: {
        email: true,
        refreshTokenVersion: true,
        refreshTokenHash: true
      },
      take: 5
    });
    
    console.log(`Found ${allUsers.length} users with refresh tokens:`);
    allUsers.forEach(u => {
      const jtiLength = u.refreshTokenVersion?.length;
      const hashExists = !!u.refreshTokenHash;
      const format = /^[a-f0-9]{64}$/i.test(u.refreshTokenVersion || '') ? '64-char-hex' : 'other';
      console.log(`  - ${u.email}: JTI=${format}(${jtiLength}), Hash=${hashExists}`);
    });
    
    // Check PrismaTokenRepositoryBridge implementation
    console.log('\n��� Bridge implementation check:');
    console.log('The bridge should:');
    console.log('  1. Store token.id (jti) as refreshTokenVersion');
    console.log('  2. Store hashed token as refreshTokenHash');
    console.log('  3. findRefreshToken() should lookup by refreshTokenVersion = jti');
    
    console.log('\n⚠️  DIAGNOSIS:');
    if (isJtiValid && isBcryptHash) {
      console.log('✅ Database state looks correct');
      console.log('❌ But refresh endpoint returns "Invalid refresh token"');
      console.log('   This suggests:');
      console.log('   1. Token validation logic error');
      console.log('   2. Wrong token being sent to bridge');
      console.log('   3. Bridge.findRefreshToken() not finding the token');
    } else {
      console.log('❌ Database state has issues');
      if (!isJtiValid) console.log('   - JTI format wrong');
      if (!isBcryptHash) console.log('   - Hash format wrong');
    }
    
  } catch (error) {
    console.error('Debug failed:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

debugTokenValidation();
