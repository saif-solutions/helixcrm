const { NestFactory } = require('@nestjs/core');
const { AppModule } = require('./src/app.module');

async function testAuditIntegrityService() {
  console.log('��� Testing Full AuditIntegrityService...');
  console.log('========================================\n');

  let app;
  
  try {
    // Create application context
    app = await NestFactory.createApplicationContext(AppModule, {
      logger: ['error', 'warn']
    });
    
    console.log('1. Getting AuditIntegrityService...');
    const auditIntegrityService = app.get('AuditIntegrityService');
    console.log('   ✅ Service retrieved');
    
    console.log('\n2. Testing appendEvent()...');
    const testEvent = {
      action: 'USER_LOGIN',
      entityType: 'AUTH',
      entityId: 'user-123',
      userId: 'user-123',
      tenantId: 'org-456',
      details: { ip: '127.0.0.1', success: true },
      timestamp: new Date(),
      metadata: { source: 'test-script' }
    };
    
    const hash = await auditIntegrityService.appendEvent(testEvent);
    console.log('   ✅ Event appended. Hash: ' + hash.substring(0, 32) + '...');
    
    console.log('\n3. Testing verifyChain()...');
    const verification = await auditIntegrityService.verifyChain();
    console.log('   ✅ Chain verification: ' + (verification.valid ? 'VALID' : 'INVALID'));
    console.log('   Total events: ' + verification.totalEvents);
    
    console.log('\n4. Testing getChainStats()...');
    const stats = await auditIntegrityService.getChainStats();
    console.log('   ✅ Chain stats retrieved');
    console.log('   Total events: ' + stats.totalEvents);
    console.log('   Chain length: ' + stats.chainLengthDays + ' days');
    
    console.log('\n5. Testing getVerificationHistory()...');
    const history = await auditIntegrityService.getVerificationHistory(5);
    console.log('   ✅ Verification history: ' + history.length + ' records');
    
    console.log('\n6. Testing integration with existing audit system...');
    const auditLogService = app.get('AuditLogService');
    console.log('   ✅ AuditLogService retrieved');
    
    // Note: We can't easily test the full integration without HTTP context,
    // but we've verified the services are properly injected
    
    console.log('\n��� All tests passed!');
    console.log('\nSummary:');
    console.log('- Audit integrity tables are working');
    console.log('- Hash chaining is functional');
    console.log('- Services are properly injected');
    console.log('- Chain verification works');
    
    return 0;
    
  } catch (error) {
    console.error('\n❌ Test failed:', error.message);
    if (error.stack) {
      console.error('Stack:', error.stack.split('\n').slice(0, 3).join('\n'));
    }
    return 1;
  } finally {
    if (app) {
      await app.close();
    }
  }
}

// Run the test
testAuditIntegrityService()
  .then(code => {
    console.log('\n' + '='.repeat(50));
    process.exit(code);
  })
  .catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
  });
