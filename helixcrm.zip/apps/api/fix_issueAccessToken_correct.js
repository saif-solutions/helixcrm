const fs = require('fs');
const path = require('path');

const filePath = path.resolve(__dirname, 'src/modules/auth/auth.service.ts');
let content = fs.readFileSync(filePath, 'utf8');

console.log('Applying CORRECT fix: .tokenManager.issueAccessToken → .authCore.issueAccessToken');

// Fix line 211: .tokenManager.issueAccessToken → .authCore.issueAccessToken
let lines = content.split('\n');
let fixedLines = [];

for (let i = 0; i < lines.length; i++) {
  let line = lines[i];
  
  // Fix both occurrences
  if (line.includes('.tokenManager.issueAccessToken(')) {
    console.log(`Fixing line ${i + 1}: ${line.substring(0, 50)}...`);
    line = line.replace('.tokenManager.issueAccessToken(', '.authCore.issueAccessToken(');
  }
  
  fixedLines.push(line);
}

content = fixedLines.join('\n');
fs.writeFileSync(filePath, content, 'utf8');
console.log('✅ Fix applied');
