const fs = require('fs');
const path = require('path');

const filePath = path.resolve(__dirname, 'src/modules/auth/auth.service.ts');
let content = fs.readFileSync(filePath, 'utf8');

console.log('Fixing auth.service.ts...');

// Count current errors
const issueAccessTokenCount = (content.match(/\.issueAccessToken/g) || []).length;
console.log(`Found ${issueAccessTokenCount} issueAccessToken calls`);

// Fix ALL .tokenManager.issueAccessToken calls to .jwt.issueToken
content = content.replace(/\.tokenManager\.issueAccessToken/g, '.jwt.issueToken');

// After fixing, we need to ensure the payload matches JwtPayload
// JwtPayload is { sub, org, role, iat, exp, version }
// Our current payload has { userId, email, organizationId, tokenVersion, permissions, roles, metadata }

// Fix first issueToken call (login)
const firstTokenMatch = content.match(/\.jwt\.issueToken\(\s*\{[^}]+userId:[^,]+,/);
if (firstTokenMatch) {
  console.log('Found first jwt.issueToken call, fixing payload...');
  // Find and replace the entire payload
  content = content.replace(
    /\.jwt\.issueToken\(\s*\{\s*userId: ([^,]+),\s*email: ([^,]+),\s*organizationId: ([^,]+),\s*tokenVersion: ([^,]+),\s*permissions: ([^,]+),\s*roles: ([^,]+),\s*metadata:/,
    `.jwt.issueToken({
          sub: $1,
          org: $3,
          role: $6.includes('SystemAdmin') ? 'admin' : 'user',
          version: $4,`
  );
}

// Fix second issueToken call (refresh)
const secondTokenMatch = content.match(/\.jwt\.issueToken\(\s*\{[^}]+userId: userWithOrg\.id,/);
if (secondTokenMatch) {
  console.log('Found second jwt.issueToken call, fixing payload...');
  content = content.replace(
    /\.jwt\.issueToken\(\s*\{\s*userId: userWithOrg\.id,\s*email: userWithOrg\.email,\s*organizationId: userWithOrg\.organizationId,\s*tokenVersion: userWithOrg\.tokenVersion \+ 1,\s*permissions: permissions,\s*roles: roles,\s*metadata:/,
    `.jwt.issueToken({
          sub: userWithOrg.id,
          org: userWithOrg.organizationId,
          role: roles.includes('SystemAdmin') ? 'admin' : 'user',
          version: userWithOrg.tokenVersion + 1,`
  );
}

// Remove any remaining metadata property from JWT payloads
content = content.replace(/,\s*metadata: \{[^}]+\}\s*\);/g, '});');

fs.writeFileSync(filePath, content, 'utf8');
console.log('✅ auth.service.ts fixed');
