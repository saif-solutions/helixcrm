const fs = require('fs');
const path = require('path');

const cliPath = path.join(__dirname, 'apps/api/scripts/compliance-cli.ts');
let content = fs.readFileSync(cliPath, 'utf8');

// Add the missing imports
if (!content.includes('import { ConfigModule }')) {
  content = content.replace(
    "import { Command } from 'commander';",
    `import { Command } from 'commander';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from '../src/shared/prisma/prisma.module';`
  );
}

// Fix the createApplicationContext calls
content = content.replace(
  /const app = await NestFactory\.createApplicationContext\(\{[\s\S]*?imports: \[ComplianceModule\],[\s\S]*?\}\);/g,
  `const app = await NestFactory.createApplicationContext({
      imports: [
        ConfigModule.forRoot({ isGlobal: true }),
        PrismaModule,
        ComplianceModule,
      ],
    });`
);

fs.writeFileSync(cliPath, content, 'utf8');
console.log('✅ CLI script fixed!');
