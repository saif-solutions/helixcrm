// apps/api/src/shared/prisma/prisma-safeguard.service.ts
import { Injectable, Logger } from '@nestjs/common';

export class TenantIsolationViolationError extends Error {
  constructor(message: string) {
    super(`SECURITY VIOLATION: ${message}`);
    this.name = 'TenantIsolationViolationError';
  }
}

@Injectable()
export class PrismaSafeguardService {
  private readonly logger = new Logger(PrismaSafeguardService.name);
  
  private readonly TENANT_TABLES = ['User', 'Contact', 'Account', 'Activity', 'AuditLog'];
  private readonly UNSAFE_ACTIONS = ['findMany', 'updateMany', 'deleteMany', 'aggregate', 'groupBy'];
  private readonly SAFE_OPERATIONS = ['create', 'createMany', 'findUnique', 'findFirst', 'update', 'delete', 'count'];

  // NO CONSTRUCTOR DEPENDENCIES - This is key!

  installMiddleware(prisma: any) {
    prisma.$use(async (params, next) => {
      if (process.env.NODE_ENV !== 'production') {
        this.logger.debug(`Prisma Query: ${params.model}.${params.action}`, {
          args: this.sanitizeArgs(params.args),
        });
      }

      this.enforceTenantIsolation(params);

      return next(params);
    });

    this.logger.log('Prisma Hard Fail Safeguard activated');
  }

  private enforceTenantIsolation(params: any) {
    const { model, action, args } = params;

    if (!this.TENANT_TABLES.includes(model)) {
      return;
    }

    if (this.UNSAFE_ACTIONS.includes(action)) {
      this.validateOrganizationIdFilter(model, action, args);
    }

    if (this.SAFE_OPERATIONS.includes(action) && process.env.NODE_ENV !== 'production') {
      this.warnMissingOrganizationId(model, action, args);
    }
  }

  private validateOrganizationIdFilter(model: string, action: string, args: any) {
    const hasOrganizationFilter = this.extractOrganizationId(args);
    
    if (!hasOrganizationFilter) {
      const error = new TenantIsolationViolationError(
        `${action} on ${model} requires organizationId filter.`
      );
      this.logger.error(error.message);
      throw error;
    }
  }

  private warnMissingOrganizationId(model: string, action: string, args: any) {
    const hasOrganizationFilter = this.extractOrganizationId(args);
    
    if (!hasOrganizationFilter && args?.where) {
      this.logger.warn(
        `⚠️ WARNING: ${action} on ${model} without organizationId filter.`
      );
    }
  }

  private extractOrganizationId(args: any): boolean {
    if (!args?.where) return false;
    
    if (args.where.organizationId) return true;
    if (args.where.organization?.id) return true;
    
    if (Array.isArray(args.where.OR)) {
      return args.where.OR.some((c: any) => c.organizationId || c.organization?.id);
    }
    
    if (Array.isArray(args.where.AND)) {
      return args.where.AND.every((c: any) => c.organizationId || c.organization?.id);
    }
    
    return false;
  }

  private sanitizeArgs(args: any): any {
    if (!args) return args;
    const sanitized = { ...args };
    
    if (sanitized.data?.passwordHash) {
      sanitized.data.passwordHash = '***REDACTED***';
    }
    
    if (sanitized.where?.passwordHash) {
      sanitized.where.passwordHash = '***REDACTED***';
    }
    
    return sanitized;
  }
}