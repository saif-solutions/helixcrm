const axios = require('axios');
const https = require('https');

const API_BASE = 'http://localhost:3001/api';
const httpsAgent = new https.Agent({ rejectUnauthorized: false });

async function testCSRF() {
  console.log('���️ TESTING CSRF AND REFRESH REQUIREMENTS\n');
  
  let cookies = {};
  let csrfToken = null;
  
  // Helper to get CSRF token first
  const getCSRFToken = async () => {
    try {
      const response = await axios.get(`${API_BASE}/auth/csrf-token`, {
        httpsAgent,
        withCredentials: true
      });
      
      if (response.headers['set-cookie']) {
        response.headers['set-cookie'].forEach(cookie => {
          if (cookie.includes('csrfToken')) {
            const match = cookie.match(/csrfToken=([^;]+)/);
            if (match) csrfToken = match[1];
          }
        });
      }
      
      return csrfToken;
    } catch (error) {
      console.error('Failed to get CSRF token:', error.message);
      return null;
    }
  };
  
  // Login first
  console.log('1. Logging in to get tokens...');
  const loginRes = await axios.post(
    `${API_BASE}/auth/login`,
    {
      email: 'test3@example.com',
      password: 'password123'
    },
    {
      headers: { 'Content-Type': 'application/json' },
      httpsAgent,
      withCredentials: true
    }
  );
  
  if (loginRes.status !== 200) {
    console.log('Login failed');
    return;
  }
  
  console.log('✅ Login successful');
  
  // Get cookies from login
  if (loginRes.headers['set-cookie']) {
    loginRes.headers['set-cookie'].forEach(cookie => {
      const [cookieStr] = cookie.split(';');
      const [name, value] = cookieStr.split('=');
      cookies[name] = value;
    });
  }
  
  console.log('Cookies received:', Object.keys(cookies));
  
  // Get CSRF token
  console.log('\n2. Getting CSRF token...');
  csrfToken = await getCSRFToken();
  console.log(`CSRF Token: ${csrfToken ? 'Received' : 'Not received'}`);
  
  // Test refresh with CSRF token
  console.log('\n3. Testing refresh with CSRF token...');
  
  const headers = {
    'Content-Type': 'application/json',
    'Cookie': Object.entries(cookies).map(([k, v]) => `${k}=${v}`).join('; ')
  };
  
  if (csrfToken) {
    headers['X-CSRF-Token'] = csrfToken;
  }
  
  try {
    const refreshRes = await axios.post(
      `${API_BASE}/auth/refresh`,
      {},
      {
        headers,
        httpsAgent,
        withCredentials: true,
        validateStatus: () => true
      }
    );
    
    console.log(`Refresh status: ${refreshRes.status}`);
    console.log(`Response: ${JSON.stringify(refreshRes.data)}`);
    
    if (refreshRes.status === 200 || refreshRes.status === 201) {
      console.log('✅ Refresh successful with CSRF token!');
    } else {
      console.log('❌ Refresh still failing');
      
      // Check if there's a different CSRF header name
      console.log('\n4. Trying different CSRF header names...');
      
      const csrfHeaders = [
        'X-CSRF-Token',
        'X-XSRF-Token', 
        'X-CSRF-TOKEN',
        'X-XSRF-TOKEN',
        'CSRF-Token',
        'X-Csrf-Token'
      ];
      
      for (const headerName of csrfHeaders) {
        const testHeaders = { ...headers };
        if (csrfToken) testHeaders[headerName] = csrfToken;
        
        const testRes = await axios.post(
          `${API_BASE}/auth/refresh`,
          {},
          { headers: testHeaders, httpsAgent, withCredentials: true, validateStatus: () => true }
        );
        
        console.log(`   ${headerName}: ${testRes.status}`);
        if (testRes.status === 200 || testRes.status === 201) {
          console.log(`   ✅ Success with ${headerName}!`);
          break;
        }
      }
    }
    
  } catch (error) {
    console.error('Refresh test failed:', error.message);
    if (error.response) {
      console.error('Response status:', error.response.status);
      console.error('Response data:', error.response.data);
    }
  }
}

testCSRF();
