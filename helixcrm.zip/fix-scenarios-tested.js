const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'apps/api/src/shared/compliance/soc2/soc2-evidence.service.ts');
let content = fs.readFileSync(filePath, 'utf8');

// Find and fix the scenariosTested array
// It's creating [undefined] because performanceResults.map(r => r.scenario) returns undefined when r.scenario doesn't exist
// We need to filter out undefined values

// Look for the line with scenariosTested
const lines = content.split('\n');
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('scenariosTested:')) {
    // Find the original line
    console.log('Found line:', i + 1, lines[i]);
    
    // Replace the problematic line
    // Original: scenariosTested: [...new Set(performanceResults.map(r => r.scenario))],
    // Fixed: scenariosTested: [...new Set(performanceResults.map(r => r.scenario).filter(s => s != null))],
    
    const original = 'scenariosTested: [...new Set(performanceResults.map(r => r.scenario))],';
    const fixed = 'scenariosTested: [...new Set(performanceResults.map(r => r.scenario).filter(s => s != null))],';
    
    if (lines[i].includes(original)) {
      lines[i] = lines[i].replace(original, fixed);
      console.log('Fixed line:', i + 1);
    } else if (lines[i].includes('scenariosTested: [...new Set(performanceResults')) {
      // Try a more flexible fix
      lines[i] = lines[i].replace(
        /scenariosTested: \[\.\.\.new Set\(performanceResults\.map\(r => r\.scenario\)\)\],/,
        'scenariosTested: [...new Set(performanceResults.map(r => r.scenario).filter(s => s != null))],'
      );
      console.log('Fixed with regex');
    }
    break;
  }
}

content = lines.join('\n');
fs.writeFileSync(filePath, content, 'utf8');
console.log('✅ Fixed scenariosTested array issue');
