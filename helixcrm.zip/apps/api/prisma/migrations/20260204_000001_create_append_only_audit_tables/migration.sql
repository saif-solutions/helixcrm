-- Migration: Create Append-Only Audit Tables for Integrity Verification
-- This creates tamper-evident audit chain tables

-- Create append-only audit chain table
CREATE TABLE "append_only_audit_chain" (
  "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
  "event_hash" TEXT NOT NULL,
  "previous_hash" TEXT NOT NULL,
  "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "block_index" INTEGER NOT NULL,
  "metadata" JSONB,
  
  -- Ensure chronological order
  CONSTRAINT "append_only_audit_chain_block_index_unique" UNIQUE ("block_index")
);

-- Create audit integrity verification log
CREATE TABLE "audit_integrity_verification" (
  "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
  "verification_timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "status" TEXT NOT NULL CHECK (status IN ('SUCCESS', 'FAILURE', 'WARNING')),
  "total_events" INTEGER NOT NULL,
  "broken_at_index" INTEGER,
  "verification_duration_ms" INTEGER NOT NULL,
  "details" JSONB
);

-- Create indexes for efficient verification
CREATE INDEX "append_only_audit_chain_event_hash_idx" ON "append_only_audit_chain"("event_hash");
CREATE INDEX "append_only_audit_chain_previous_hash_idx" ON "append_only_audit_chain"("previous_hash");
CREATE INDEX "append_only_audit_chain_block_index_idx" ON "append_only_audit_chain"("block_index");
CREATE INDEX "append_only_audit_chain_timestamp_idx" ON "append_only_audit_chain"("timestamp");

CREATE INDEX "audit_integrity_verification_timestamp_idx" ON "audit_integrity_verification"("verification_timestamp");
CREATE INDEX "audit_integrity_verification_status_idx" ON "audit_integrity_verification"("status");
CREATE INDEX "audit_integrity_verification_broken_at_idx" ON "audit_integrity_verification"("broken_at_index");

-- Add RLS policies for these tables (optional - for multi-tenant)
ALTER TABLE "append_only_audit_chain" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "audit_integrity_verification" ENABLE ROW LEVEL SECURITY;

-- Function to prevent updates/deletes (append-only enforcement at DB level)
CREATE OR REPLACE FUNCTION prevent_audit_chain_updates()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    RAISE EXCEPTION 'AppendOnlyAuditChain is append-only. Updates are not allowed.';
  ELSIF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'AppendOnlyAuditChain is append-only. Deletes are not allowed.';
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER prevent_append_only_audit_chain_updates
  BEFORE UPDATE OR DELETE ON "append_only_audit_chain"
  FOR EACH ROW
  EXECUTE FUNCTION prevent_audit_chain_updates();

CREATE OR REPLACE FUNCTION prevent_verification_updates()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    RAISE EXCEPTION 'AuditIntegrityVerification is append-only. Updates are not allowed.';
  ELSIF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'AuditIntegrityVerification is append-only. Deletes are not allowed.';
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER prevent_verification_updates
  BEFORE UPDATE OR DELETE ON "audit_integrity_verification"
  FOR EACH ROW
  EXECUTE FUNCTION prevent_verification_updates();

-- Simplified function to verify audit chain integrity (fixed syntax)
CREATE OR REPLACE FUNCTION verify_audit_chain_integrity_simple()
RETURNS TABLE(
  is_valid BOOLEAN,
  total_events INTEGER,
  broken_at_index INTEGER,
  first_event_timestamp TIMESTAMP,
  last_event_timestamp TIMESTAMP
) AS $$
DECLARE
  genesis_hash TEXT := '0000000000000000000000000000000000000000000000000000000000000000';
  rec RECORD;
  prev_hash TEXT;
  event_count INTEGER := 0;
  broken_index INTEGER := NULL;
  first_ts TIMESTAMP;
  last_ts TIMESTAMP;
BEGIN
  -- Get all events in order
  FOR rec IN 
    SELECT block_index, event_hash, previous_hash, metadata, timestamp 
    FROM append_only_audit_chain 
    ORDER BY block_index ASC
  LOOP
    event_count := event_count + 1;
    
    IF event_count = 1 THEN
      first_ts := rec.timestamp;
      -- First event should point to genesis hash
      IF rec.previous_hash != genesis_hash THEN
        broken_index := rec.block_index;
        is_valid := FALSE;
        total_events := event_count;
        first_event_timestamp := first_ts;
        last_event_timestamp := rec.timestamp;
        RETURN NEXT;
        RETURN;
      END IF;
    ELSE
      -- Verify chain link
      IF rec.previous_hash != prev_hash THEN
        broken_index := rec.block_index;
        is_valid := FALSE;
        total_events := event_count;
        first_event_timestamp := first_ts;
        last_event_timestamp := rec.timestamp;
        RETURN NEXT;
        RETURN;
      END IF;
    END IF;
    
    prev_hash := rec.event_hash;
    last_ts := rec.timestamp;
  END LOOP;
  
  -- If we get here, chain is valid
  is_valid := TRUE;
  total_events := event_count;
  broken_at_index := NULL;
  first_event_timestamp := first_ts;
  last_event_timestamp := last_ts;
  
  RETURN NEXT;
END;
$$ LANGUAGE plpgsql;
