const fs = require('fs');
const path = require('path');

const filePath = path.resolve(__dirname, 'src/modules/auth/auth.service.ts');
let content = fs.readFileSync(filePath, 'utf8', 'utf8');

// Fix first payload (login)
content = content.replace(
  /\.jwt\.issueToken\(\{\s*userId: ([^,]+),\s*email: ([^,]+),\s*organizationId: ([^,]+),\s*tokenVersion: ([^,]+),\s*permissions: ([^,]+),\s*roles: ([^,]+),\s*metadata:/,
  `.jwt.issueToken({
          sub: $1,  // userId → sub
          org: $3,  // organizationId → org
          role: 'user',  // Default role
          version: $4,  // tokenVersion → version
          // Note: email, permissions, roles not in JwtPayload contract
          metadata:`
);

// Fix second payload (refresh)
content = content.replace(
  /\.jwt\.issueToken\(\{\s*userId: ([^,]+),\s*email: ([^,]+),\s*organizationId: ([^,]+),\s*tokenVersion: ([^,]+),\s*permissions: ([^,]+),\s*roles: ([^,]+),\s*metadata:/,
  `.jwt.issueToken({
          sub: $1,  // userId → sub
          org: $3,  // organizationId → org
          role: 'user',  // Default role
          version: $4,  // tokenVersion → version
          // Note: email, permissions, roles not in JwtPayload contract
          metadata:`
);

fs.writeFileSync(filePath, content, 'utf8');
console.log('✅ JWT payloads fixed for JwtService contract');
