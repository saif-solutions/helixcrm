const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function checkUsers() {
  try {
    const users = await prisma.user.findMany({
      select: {
        email: true,
        isActive: true,
        failedLoginAttempts: true,
        lockedUntil: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'asc' }
    });
    
    console.log('Available users for testing:');
    console.log('=' .repeat(50));
    
    users.forEach((user, index) => {
      console.log(`${index + 1}. ${user.email}`);
      console.log(`   Active: ${user.isActive}`);
      console.log(`   Failed attempts: ${user.failedLoginAttempts}`);
      console.log(`   Locked until: ${user.lockedUntil || 'Not locked'}`);
      console.log(`   Created: ${user.createdAt.toISOString().split('T')[0]}`);
      console.log('');
    });
    
    console.log('Note: Most seed users use password: "password123"');
    console.log('      Some may use: "Password123!" or "password"');
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

checkUsers();
