const fs = require('fs');
const path = require('path');

const packagePath = path.join(__dirname, 'package.json');
const packageJson = JSON.parse(fs.readFileSync(packagePath, 'utf8'));

// Ensure we have all required scripts
packageJson.scripts = {
  ...packageJson.scripts,
  'lint': 'eslint "{src,test}/**/*.ts" --fix',
  'type-check': 'tsc --noEmit',
  'test:ci': 'npm run type-check && npm run test:unit',
  'ci:full': 'npm run type-check && npm run test:unit && npm run test:integration && npm run test:contracts && npm run test:security'
};

// Add Jest as dev dependency if not present
if (!packageJson.devDependencies.jest) {
  packageJson.devDependencies.jest = "^29.7.0";
}

fs.writeFileSync(packagePath, JSON.stringify(packageJson, null, 2));
console.log('✅ Updated package.json with CI scripts');
