# Phase 3 Database Hardening Migration

## Changes:
1. Added `RefreshToken` table for secure token storage
2. Added soft delete fields (`deletedAt`, `deletedBy`) to all tenant models
3. Added `lastPasswordChange` and `mustChangePassword` to User model
4. Added unique constraint for email per organization
5. Added performance indexes for tenant isolation

## Models Affected:
- User: Added password tracking fields
- Contact: Added soft delete
- Lead: Added soft delete  
- Account: Added soft delete
- Activity: Added soft delete
- Deal: Added deletedBy field
- Pipeline: Added soft delete
- PipelineStage: Added soft delete
- Role: Added soft delete
- UserRole: Added soft delete
- New: RefreshToken table

## SQL Operations:
- CREATE TABLE refresh_tokens
- ALTER TABLE for soft delete columns
- DROP INDEX users_organizationId_email_idx
- CREATE UNIQUE CONSTRAINT users_organizationId_email_key
- CREATE INDEX for performance

## Rollback:
To rollback, revert this migration and restore from backup.
