const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function checkAllUsers() {
  try {
    const users = await prisma.user.findMany({
      select: {
        id: true,
        email: true,
        refreshTokenVersion: true,
        refreshTokenHash: true,
      },
      where: {
        refreshTokenVersion: { not: null }
      }
    });
    
    console.log(`Found ${users.length} users with non-null refreshTokenVersion`);
    
    users.forEach(user => {
      const version = user.refreshTokenVersion;
      let format = 'UNKNOWN';
      
      if (!version) format = 'NULL';
      else if (/^[a-f0-9]{64}$/i.test(version)) format = '64-CHAR-HEX-HASH';
      else if (version.includes('-') && version.length > 20) format = 'TIMESTAMP-UUID';
      else if (version.includes(':')) format = 'USERID:JTI';
      
      console.log(`- ${user.email}: ${format} (${version?.length} chars)`);
      if (format === 'TIMESTAMP-UUID') {
        console.log(`  Sample: ${version.substring(0, 30)}...`);
      }
    });
    
    // Count formats
    const formatCounts = users.reduce((acc, user) => {
      const version = user.refreshTokenVersion;
      let format = 'UNKNOWN';
      
      if (!version) format = 'NULL';
      else if (/^[a-f0-9]{64}$/i.test(version)) format = '64-CHAR-HEX-HASH';
      else if (version.includes('-') && version.length > 20) format = 'TIMESTAMP-UUID';
      else if (version.includes(':')) format = 'USERID:JTI';
      
      acc[format] = (acc[format] || 0) + 1;
      return acc;
    }, {});
    
    console.log('\nFormat distribution:');
    console.log(formatCounts);
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

checkAllUsers();
