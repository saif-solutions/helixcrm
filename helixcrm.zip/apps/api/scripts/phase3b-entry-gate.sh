#!/bin/bash

echo "��� PHASE 3B ENTRY GATE - Safety Check"
echo "=========================================="
echo "Purpose: Eliminate environment-based false failures"
echo "Expected time: 15 minutes"
echo ""

# Step 1: Fresh restart
echo "��� Step 1: Fresh restart of services..."
docker-compose down -v
docker-compose up -d postgres

# Wait for PostgreSQL to be ready
echo "⏳ Waiting for PostgreSQL to be ready..."
sleep 10

# Step 2: Start the API in development mode
echo "��� Step 2: Starting API in development mode..."
npm run start:dev &
API_PID=$!

# Wait for API to start
echo "⏳ Waiting for API to start..."
sleep 15

# Step 3: Run validation scripts
echo "��� Step 3: Running validation scripts..."

echo ""
echo "��� Running phase3b-validation.ts..."
npx ts-node src/modules/auth/adapters/phase3b-validation.ts
VALIDATION_RESULT=$?

echo ""
echo "��� Running transaction-verify.ts..."
npx ts-node src/modules/auth/adapters/transaction-verify.ts
TRANSACTION_RESULT=$?

# Step 4: Stop the API
echo ""
echo "��� Stopping API..."
kill $API_PID 2>/dev/null

# Step 5: Confirm results
echo ""
echo "��� ENTRY GATE RESULTS:"
echo "======================"

if [ $VALIDATION_RESULT -eq 0 ] && [ $TRANSACTION_RESULT -eq 0 ]; then
    echo "✅ SUCCESS: All checks passed cleanly"
    echo ""
    echo "��� ENTRY CRITERIA MET:"
    echo "   - No warnings"
    echo "   - No retries" 
    echo "   - No manual intervention"
    echo "   - Environment is clean"
    echo ""
    echo "��� PROCEED TO FULL QA CHECKLIST EXECUTION"
    exit 0
else
    echo "❌ FAILURE: One or more checks failed"
    echo ""
    echo "⚠️  DO NOT PROCEED:"
    echo "   - Check environment configuration"
    echo "   - Verify database is running"
    echo "   - Review error messages above"
    echo ""
    echo "After fixing issues, run this gate again."
    exit 1
fi
