const { PrismaClient } = require('@prisma/client');

async function checkStructure() {
  console.log('Checking actual table structure in database...\n');
  
  const prisma = new PrismaClient();
  
  try {
    // Check deal_daily_summaries columns
    const columns = await prisma.$queryRaw`
      SELECT column_name, data_type, is_nullable
      FROM information_schema.columns
      WHERE table_schema = 'public' 
        AND table_name = 'deal_daily_summaries'
      ORDER BY ordinal_position;
    `;
    
    console.log('Columns in deal_daily_summaries table:');
    console.log('----------------------------------------');
    columns.forEach(col => {
      console.log(`${col.column_name.padEnd(25)} ${col.data_type.padEnd(20)} ${col.is_nullable}`);
    });
    
    // Also check the Prisma model
    console.log('\nExpected by Prisma (from schema):');
    console.log('organizationId (camelCase) should map to organization_id (snake_case)');
    
  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

checkStructure();
