const { PrismaClient } = require('@prisma/client');

async function testRawInsert() {
  console.log('Testing raw SQL insert with correct column names...\n');
  
  const prisma = new PrismaClient();
  
  try {
    const org = await prisma.organization.findFirst();
    if (!org) {
      console.log('No organization found');
      return;
    }
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Try raw SQL with correct column names
    const result = await prisma.$executeRaw`
      INSERT INTO deal_daily_summaries (
        organization_id, 
        date, 
        total_deals, 
        won_deals, 
        lost_deals, 
        open_deals,
        total_amount,
        won_amount,
        average_deal_size,
        win_rate,
        currency,
        pipeline_id,
        stage_id,
        created_at,
        updated_at,
        summarized_at
      ) VALUES (
        ${org.id},
        ${today},
        ${10},
        ${5},
        ${2},
        ${3},
        ${100000},
        ${50000},
        ${10000},
        ${50},
        'USD',
        NULL,
        NULL,
        NOW(),
        NOW(),
        NOW()
      )
      RETURNING id
    `;
    
    console.log('✅ Raw insert successful!');
    console.log('Result:', result);
    
    // Now try to read with Prisma
    const records = await prisma.dealDailySummary.findMany();
    console.log(`\nRecords found via Prisma: ${records.length}`);
    
    if (records.length > 0) {
      console.log('First record:', JSON.stringify(records[0], null, 2));
    }
    
    // Clean up
    await prisma.$executeRaw`DELETE FROM deal_daily_summaries`;
    console.log('\n✅ Cleaned up test data');
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

testRawInsert();
