const fs = require('fs');
const path = require('path');

const filePath = path.resolve(__dirname, 'src/modules/auth/auth.service.ts');
let content = fs.readFileSync(filePath, 'utf8');

console.log('Fixing JWT payload format for AuthCoreContract...');

// AuthCoreContract.issueAccessToken expects Omit<JwtPayload, 'iat' | 'exp'>
// JwtPayload = { sub, org, role, iat, exp, version }

// Find and fix first payload (login)
const firstPayloadStart = content.indexOf('const accessToken = await this.authCoreAdapter.authCore.issueAccessToken({');
if (firstPayloadStart !== -1) {
  console.log('Found first payload, fixing...');
  // Extract from first payload to its closing });
  let payloadEnd = content.indexOf('});', firstPayloadStart);
  let payload = content.substring(firstPayloadStart, payloadEnd + 2);
  
  // Replace with correct JwtPayload format
  const fixedPayload = `      const accessToken = await this.authCoreAdapter.authCore.issueAccessToken({
        sub: user.id,
        org: user.organizationId,
        role: roles.includes('SystemAdmin') ? 'admin' : 'user',
        version: user.tokenVersion,
      });`;
  
  content = content.substring(0, firstPayloadStart) + fixedPayload + content.substring(payloadEnd + 2);
}

// Find and fix second payload (refresh)
const secondPayloadStart = content.indexOf('const newAccessToken = await this.authCoreAdapter.authCore.issueAccessToken({');
if (secondPayloadStart !== -1) {
  console.log('Found second payload, fixing...');
  let payloadEnd = content.indexOf('});', secondPayloadStart);
  let payload = content.substring(secondPayloadStart, payloadEnd + 2);
  
  const fixedPayload = `          const newAccessToken = await this.authCoreAdapter.authCore.issueAccessToken({
            sub: userWithOrg.id,
            org: userWithOrg.organizationId,
            role: roles.includes('SystemAdmin') ? 'admin' : 'user',
            version: userWithOrg.tokenVersion + 1,
          });`;
  
  content = content.substring(0, secondPayloadStart) + fixedPayload + content.substring(payloadEnd + 2);
}

fs.writeFileSync(filePath, content, 'utf8');
console.log('✅ JWT payloads fixed for AuthCoreContract');
