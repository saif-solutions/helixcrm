const { PrismaClient } = require('@prisma/client');

async function migrateAuditEnums() {
  const prisma = new PrismaClient();
  
  console.log('��� Starting ENUM migration for audit logs...');
  
  try {
    // First, check current state
    const currentData = await prisma.$queryRaw`
      SELECT 
        column_name, 
        data_type,
        udt_name
      FROM information_schema.columns 
      WHERE table_name = 'audit_logs'
      AND column_name IN ('actorType', 'action', 'entityType', 'severity')
    `;
    
    console.log('��� Current column types:', currentData);
    
    // Check existing enum values
    const enumValues = await prisma.$queryRaw`
      SELECT 
        DISTINCT "actorType" as actor_type,
        COUNT(*) as count
      FROM audit_logs
      GROUP BY "actorType"
      ORDER BY count DESC
    `;
    
    console.log('��� Current actorType distribution:');
    console.table(enumValues);
    
    // Convert lowercase 'user'/'system' to uppercase if they exist
    const needsMigration = enumValues.some(row => 
      row.actor_type === 'user' || row.actor_type === 'system'
    );
    
    if (needsMigration) {
      console.log('��� Converting lowercase values to uppercase...');
      
      await prisma.$executeRaw`
        UPDATE audit_logs 
        SET 
          "actorType" = UPPER("actorType"),
          action = UPPER(action),
          "entityType" = UPPER("entityType"),
          severity = UPPER(severity)
        WHERE 
          "actorType" IN ('user', 'system') OR
          action IS NOT NULL OR
          "entityType" IS NOT NULL OR
          severity IS NOT NULL
      `;
      
      console.log('✅ Converted values to uppercase');
    } else {
      console.log('✅ No lowercase values found, skipping conversion');
    }
    
    // Set defaults for null values
    console.log('��� Setting defaults for null values...');
    await prisma.$executeRaw`
      UPDATE audit_logs 
      SET "actorType" = 'USER' 
      WHERE "actorType" IS NULL
    `;
    
    // Verify the migration
    const postMigration = await prisma.$queryRaw`
      SELECT 
        DISTINCT "actorType" as actor_type,
        COUNT(*) as count
      FROM audit_logs
      GROUP BY "actorType"
      ORDER BY count DESC
    `;
    
    console.log('��� Post-migration actorType distribution:');
    console.table(postMigration);
    
    console.log('✅ ENUM migration completed successfully!');
    
  } catch (error) {
    console.error('❌ Migration failed:', error.message);
    console.error('Full error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

migrateAuditEnums();
