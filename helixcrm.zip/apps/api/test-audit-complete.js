const { PrismaClient } = require('@prisma/client');
const axios = require('axios');

async function testAuditComplete() {
  const prisma = new PrismaClient();
  
  console.log('��� STARTING COMPREHENSIVE AUDIT LOG TEST ���');
  console.log('=' .repeat(50));
  
  try {
    // 1. Test Prisma connection and schema
    console.log('\n1️⃣ Testing Prisma connection...');
    const prismaVersion = await prisma.$queryRaw`SELECT version()`;
    console.log('✅ Database version:', prismaVersion[0].version);
    
    // 2. Check audit_logs table structure
    console.log('\n2️⃣ Checking audit_logs table structure...');
    const tableInfo = await prisma.$queryRaw`
      SELECT 
        column_name,
        data_type,
        udt_name,
        is_nullable
      FROM information_schema.columns 
      WHERE table_name = 'audit_logs'
      ORDER BY ordinal_position
    `;
    
    console.log('��� Table columns:');
    console.table(tableInfo);
    
    // 3. Test creating an audit log with Prisma enums
    console.log('\n3️⃣ Testing audit log creation with Prisma enums...');
    
    const testAuditLog = await prisma.auditLog.create({
      data: {
        action: 'LOGIN_SUCCESS',
        entityType: 'AUTH',
        entityId: 'test-user-123',
        organizationId: '00000000-0000-0000-0000-000000000000',
        actorEmail: 'test@test.com',
        actorType: 'USER',
        severity: 'MEDIUM',
        ipAddress: '127.0.0.1',
        userAgent: 'Test Script',
        metadata: { test: true }
      }
    });
    
    console.log('✅ Audit log created successfully!');
    console.log('   ID:', testAuditLog.id);
    console.log('   Action:', testAuditLog.action);
    console.log('   Actor Type:', testAuditLog.actorType);
    
    // 4. Verify the created log has correct values
    console.log('\n4️⃣ Verifying enum values are uppercase...');
    const verifyLog = await prisma.auditLog.findUnique({
      where: { id: testAuditLog.id }
    });
    
    if (verifyLog.actorType === 'USER' && verifyLog.action === 'LOGIN_SUCCESS') {
      console.log('✅ Enum values are correct (uppercase)');
    } else {
      console.error('❌ Enum values are incorrect!');
      console.log('   Expected USER, got:', verifyLog.actorType);
      console.log('   Expected LOGIN_SUCCESS, got:', verifyLog.action);
    }
    
    // 5. Test querying audit logs
    console.log('\n5️⃣ Testing audit log queries...');
    const allLogs = await prisma.auditLog.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' }
    });
    
    console.log(`��� Found ${allLogs.length} total audit logs`);
    console.log('Recent logs:');
    allLogs.forEach((log, i) => {
      console.log(`   ${i+1}. ${log.action} by ${log.actorEmail} (${log.actorType})`);
    });
    
    // 6. Test authentication API (if server is running)
    console.log('\n6️⃣ Testing authentication API...');
    try {
      const serverUrl = 'http://localhost:3001';
      console.log(`   Testing server at ${serverUrl}`);
      
      // Quick health check
      const healthResponse = await axios.get(`${serverUrl}/health`, { timeout: 5000 });
      console.log(`✅ Server is running: ${healthResponse.status}`);
      
      // Try login (if test user exists)
      console.log('   Attempting test login...');
      try {
        const loginResponse = await axios.post(
          `${serverUrl}/api/v1/auth/login`,
          {
            email: 'admin@test.com',
            password: 'TestPass123!'
          },
          { timeout: 5000 }
        );
        
        if (loginResponse.data?.accessToken) {
          console.log('✅ Login successful!');
          
          // Check if audit log was created for login
          setTimeout(async () => {
            const latestLogs = await prisma.auditLog.findMany({
              where: { action: 'LOGIN_SUCCESS' },
              orderBy: { createdAt: 'desc' },
              take: 1
            });
            
            if (latestLogs.length > 0) {
              const latestLogin = latestLogs[0];
              console.log(`   Latest login audit: ${latestLogin.actorEmail} at ${latestLogin.createdAt}`);
            }
          }, 1000);
          
        }
      } catch (loginError) {
        console.log('⚠️  Login failed (might be expected):', loginError.response?.data?.message || loginError.message);
      }
      
    } catch (apiError) {
      console.log('⚠️  API test skipped (server might not be running):', apiError.message);
    }
    
    // 7. Test extended action support
    console.log('\n7️⃣ Testing extended action support...');
    
    // Create a log with extended action (stored in metadata)
    const extendedLog = await prisma.auditLog.create({
      data: {
        action: 'SYSTEM_ERROR', // Using Prisma enum
        entityType: 'SYSTEM',
        organizationId: '00000000-0000-0000-0000-000000000000',
        actorEmail: 'system@helixcrm',
        actorType: 'SYSTEM',
        severity: 'MEDIUM',
        metadata: {
          _extendedAction: 'ROLE_CREATED',
          _originalAction: 'ROLE_CREATED',
          roleName: 'Test Role',
          userId: 'test-user-456'
        }
      }
    });
    
    console.log('✅ Extended action log created');
    console.log('   Action:', extendedLog.action);
    console.log('   Extended Action in metadata:', extendedLog.metadata?._extendedAction);
    
    // 8. Clean up test data
    console.log('\n8️⃣ Cleaning up test data...');
    await prisma.auditLog.deleteMany({
      where: {
        OR: [
          { id: testAuditLog.id },
          { id: extendedLog.id },
          { actorEmail: 'test@test.com' }
        ]
      }
    });
    
    console.log('✅ Test data cleaned up');
    
    // 9. Final verification
    console.log('\n9️⃣ Final verification...');
    const finalCount = await prisma.auditLog.count();
    console.log(`��� Total audit logs in database: ${finalCount}`);
    
    // Check for any lowercase values
    const lowercaseCheck = await prisma.$queryRaw`
      SELECT COUNT(*) as lowercase_count
      FROM audit_logs 
      WHERE 
        "actorType" IN ('user', 'system') OR
        LOWER(action) = action OR
        LOWER("entityType") = "entityType" OR
        LOWER(severity) = severity
    `;
    
    if (lowercaseCheck[0].lowercase_count === 0) {
      console.log('✅ No lowercase enum values found!');
    } else {
      console.error(`❌ Found ${lowercaseCheck[0].lowercase_count} lowercase values!`);
    }
    
    console.log('\n' + '=' .repeat(50));
    console.log('��� AUDIT LOG SYSTEM VERIFICATION COMPLETE! ���');
    console.log('✅ All tests passed successfully');
    console.log('✅ Database schema is correct');
    console.log('✅ ENUM values are uppercase');
    console.log('✅ Audit logging is working');
    
  } catch (error) {
    console.error('\n❌ TEST FAILED:', error.message);
    console.error('Full error:', error);
  } finally {
    await prisma.$disconnect();
    console.log('\n��� Prisma disconnected');
  }
}

testAuditComplete();
