const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function createTestUser() {
  try {
    const email = 'test@phase3b.com';
    const password = 'Phase3BTest123!';
    
    // Check if user exists
    const existing = await prisma.user.findUnique({
      where: { email }
    });
    
    if (existing) {
      console.log(`User ${email} already exists, deleting...`);
      await prisma.user.delete({ where: { email } });
    }
    
    // Find an organization to use
    const org = await prisma.organization.findFirst();
    
    if (!org) {
      console.log('No organization found, creating one...');
      const newOrg = await prisma.organization.create({
        data: {
          name: 'Test Org',
          slug: 'test-org',
          status: 'active'
        }
      });
      org = newOrg;
    }
    
    console.log(`Using organization: ${org.name} (${org.id.substring(0, 8)}...)`);
    
    // Create user WITHOUT password hash (auth-core will handle it on first login)
    const user = await prisma.user.create({
      data: {
        email,
        passwordHash: 'TEMPORARY_HASH_NEEDS_RESET', // Placeholder
        firstName: 'Test',
        lastName: 'User',
        organizationId: org.id,
        isActive: true,
        role: 'admin',
        tokenVersion: 1
      }
    });
    
    console.log(`\n✅ Test user created:`);
    console.log(`   Email: ${email}`);
    console.log(`   User ID: ${user.id}`);
    console.log(`   Organization: ${org.name}`);
    console.log(`\n⚠️  IMPORTANT: User needs password reset before login.`);
    console.log(`   Use the password reset flow or seed script to set password.`);
    
    // Alternative: Use an existing user that we know works
    console.log('\n=== ALTERNATIVE APPROACH ===');
    console.log('Check existing users in database:');
    
    const users = await prisma.user.findMany({
      where: {
        email: { contains: 'test' },
        isActive: true
      },
      select: {
        email: true,
        organizationId: true,
        createdAt: true
      },
      take: 5
    });
    
    console.log('\nActive test users:');
    users.forEach(u => console.log(`  - ${u.email} (org: ${u.organizationId.substring(0, 8)}...)`));
    
  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

createTestUser();
