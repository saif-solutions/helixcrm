const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function executeSql(sql) {
  try {
    await prisma.$executeRawUnsafe(sql);
    console.log(`✅ Executed: ${sql.split('\n')[0].substring(0, 60)}...`);
    return true;
  } catch (error) {
    // Check if table already exists (error code 42P07)
    if (error.message.includes('already exists') || error.message.includes('42P07')) {
      console.log(`ℹ️  Table already exists: ${sql.split('TABLE IF NOT EXISTS')[1]?.split('(')[0]?.trim() || 'unknown'}`);
      return true;
    }
    console.error(`❌ Error: ${error.message}`);
    return false;
  }
}

async function createTables() {
  console.log('Creating analytics summary tables (one by one)...\n');
  
  const tableQueries = [
    `CREATE TABLE IF NOT EXISTS deal_daily_summaries (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      organization_id TEXT NOT NULL,
      date TIMESTAMP NOT NULL,
      total_deals INT DEFAULT 0,
      won_deals INT DEFAULT 0,
      lost_deals INT DEFAULT 0,
      open_deals INT DEFAULT 0,
      total_amount DECIMAL(15, 2),
      won_amount DECIMAL(15, 2),
      average_deal_size DECIMAL(15, 2),
      win_rate DECIMAL(5, 2),
      currency TEXT DEFAULT 'USD',
      pipeline_id TEXT,
      stage_id TEXT,
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW(),
      summarized_at TIMESTAMP DEFAULT NOW(),
      UNIQUE(organization_id, date, pipeline_id, stage_id, currency)
    )`,

    `CREATE TABLE IF NOT EXISTS revenue_daily_summaries (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      organization_id TEXT NOT NULL,
      date TIMESTAMP NOT NULL,
      total_revenue DECIMAL(15, 2),
      won_revenue DECIMAL(15, 2),
      forecast_revenue DECIMAL(15, 2),
      total_deals INT DEFAULT 0,
      won_deals INT DEFAULT 0,
      average_deal_size DECIMAL(15, 2),
      currency TEXT DEFAULT 'USD',
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW(),
      summarized_at TIMESTAMP DEFAULT NOW(),
      UNIQUE(organization_id, date, currency)
    )`,

    `CREATE TABLE IF NOT EXISTS pipeline_stage_summaries (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      organization_id TEXT NOT NULL,
      pipeline_id TEXT NOT NULL,
      stage_id TEXT NOT NULL,
      date TIMESTAMP NOT NULL,
      deal_count INT DEFAULT 0,
      total_amount DECIMAL(15, 2),
      average_amount DECIMAL(15, 2),
      avg_stage_duration INT DEFAULT 0,
      max_stage_duration INT DEFAULT 0,
      is_bottleneck BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW(),
      summarized_at TIMESTAMP DEFAULT NOW(),
      UNIQUE(organization_id, pipeline_id, stage_id, date)
    )`,

    `CREATE TABLE IF NOT EXISTS activity_daily_summaries (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      organization_id TEXT NOT NULL,
      date TIMESTAMP NOT NULL,
      login_count INT DEFAULT 0,
      deal_created INT DEFAULT 0,
      deal_updated INT DEFAULT 0,
      deal_won INT DEFAULT 0,
      deal_lost INT DEFAULT 0,
      contact_created INT DEFAULT 0,
      contact_updated INT DEFAULT 0,
      lead_created INT DEFAULT 0,
      lead_converted INT DEFAULT 0,
      active_users INT DEFAULT 0,
      total_actions INT DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW(),
      summarized_at TIMESTAMP DEFAULT NOW(),
      UNIQUE(organization_id, date)
    )`
  ];

  const indexQueries = [
    `CREATE INDEX IF NOT EXISTS idx_deal_daily_summaries_org_date ON deal_daily_summaries(organization_id, date)`,
    `CREATE INDEX IF NOT EXISTS idx_deal_daily_summaries_summarized ON deal_daily_summaries(summarized_at)`,
    `CREATE INDEX IF NOT EXISTS idx_revenue_daily_summaries_org_date ON revenue_daily_summaries(organization_id, date)`,
    `CREATE INDEX IF NOT EXISTS idx_revenue_daily_summaries_summarized ON revenue_daily_summaries(summarized_at)`,
    `CREATE INDEX IF NOT EXISTS idx_pipeline_stage_summaries_org_date ON pipeline_stage_summaries(organization_id, date)`,
    `CREATE INDEX IF NOT EXISTS idx_pipeline_stage_summaries_pipeline_stage ON pipeline_stage_summaries(pipeline_id, stage_id)`,
    `CREATE INDEX IF NOT EXISTS idx_pipeline_stage_summaries_bottleneck ON pipeline_stage_summaries(is_bottleneck)`,
    `CREATE INDEX IF NOT EXISTS idx_activity_daily_summaries_org_date ON activity_daily_summaries(organization_id, date)`,
    `CREATE INDEX IF NOT EXISTS idx_activity_daily_summaries_summarized ON activity_daily_summaries(summarized_at)`
  ];

  console.log('Creating tables...');
  for (const query of tableQueries) {
    await executeSql(query);
  }

  console.log('\nCreating indexes...');
  for (const query of indexQueries) {
    await executeSql(query);
  }

  console.log('\n✅ All tables and indexes created successfully!');
}

createTables().catch(console.error).finally(() => prisma.$disconnect());
