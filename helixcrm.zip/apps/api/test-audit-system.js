const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

async function testAuditSystem() {
  console.log('��� Testing Audit Integrity System...');
  console.log('=====================================\n');

  try {
    // Test 1: Check if tables exist
    console.log('1. Checking database tables...');
    const { stdout: tableCheck } = await execPromise(
      'npx prisma db execute --stdin --schema=prisma/schema.prisma',
      {
        input: `
          SELECT 
            table_name,
            (SELECT COUNT(*) FROM information_schema.tables WHERE table_name = t.table_name) as exists
          FROM (VALUES 
            ('append_only_audit_chain'),
            ('audit_integrity_verification')
          ) AS t(table_name);
        `
      }
    );
    
    console.log('Table check result:', tableCheck);

    // Test 2: Create a test audit event
    console.log('\n2. Testing audit event creation...');
    
    // Create a simple NestJS app context to test the service
    const testScript = `
      const { NestFactory } = require('@nestjs/core');
      const { AppModule } = require('./src/app.module');
      const { AuditIntegrityService } = require('./src/shared/audit-integrity/audit-integrity.service');

      async function test() {
        console.log('Starting test...');
        const app = await NestFactory.createApplicationContext(AppModule, {
          logger: false
        });
        
        try {
          const service = app.get(AuditIntegrityService);
          
          // Test appending an event
          const event = {
            action: 'TEST_ACTION',
            entityType: 'TEST',
            entityId: 'test-123',
            userId: 'user-test',
            tenantId: 'tenant-test',
            details: { test: true },
            timestamp: new Date()
          };
          
          const hash = await service.appendEvent(event);
          console.log('✅ Event appended to chain. Hash:', hash.substring(0, 32) + '...');
          
          // Test verification
          const result = await service.verifyChain();
          console.log('✅ Chain verification result:', result.valid ? 'VALID' : 'INVALID');
          
          // Test getting stats
          const stats = await service.getChainStats();
          console.log('✅ Chain stats:', stats.totalEvents, 'events');
          
          return 0;
        } catch (error) {
          console.error('❌ Test failed:', error.message);
          return 1;
        } finally {
          await app.close();
        }
      }
      
      test().then(code => process.exit(code));
    `;

    // Write test script to temp file and run it
    const fs = require('fs');
    const path = require('path');
    const tempFile = path.join(__dirname, 'temp-test-audit.js');
    fs.writeFileSync(tempFile, testScript);
    
    const { stdout: testOutput, stderr: testError } = await execPromise(`node ${tempFile}`);
    console.log('Test output:', testOutput);
    
    if (testError) {
      console.error('Test error:', testError);
    }
    
    // Clean up
    fs.unlinkSync(tempFile);

    console.log('\n✅ All tests completed!');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exit(1);
  }
}

testAuditSystem();
