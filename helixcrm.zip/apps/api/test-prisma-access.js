const { PrismaClient } = require('@prisma/client');

async function testAccess() {
  console.log('Testing Prisma access with updated schema...\n');
  
  const prisma = new PrismaClient();
  
  try {
    // 1. Count records
    const count = await prisma.dealDailySummary.count();
    console.log(`1. Count records: ${count}`);
    
    // 2. Create a record
    const org = await prisma.organization.findFirst();
    if (org) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const record = await prisma.dealDailySummary.create({
        data: {
          organizationId: org.id,
          date: today,
          totalDeals: 10,
          wonDeals: 5,
          lostDeals: 2,
          openDeals: 3,
          totalAmount: 100000,
          wonAmount: 50000,
          averageDealSize: 10000,
          winRate: 50,
          currency: 'USD',
          pipelineId: null,
          stageId: null,
        },
      });
      
      console.log(`2. Created record: ${record.id}`);
      
      // 3. Read the record
      const found = await prisma.dealDailySummary.findUnique({
        where: { id: record.id },
      });
      
      console.log(`3. Read record: ${found ? 'Success' : 'Failed'}`);
      console.log(`   Total deals: ${found?.totalDeals}`);
      
      // 4. Update the record
      const updated = await prisma.dealDailySummary.update({
        where: { id: record.id },
        data: { totalDeals: 15 },
      });
      
      console.log(`4. Updated record: totalDeals = ${updated.totalDeals}`);
      
      // 5. Delete the record
      await prisma.dealDailySummary.delete({
        where: { id: record.id },
      });
      
      console.log(`5. Deleted record`);
      
      console.log('\n✅ All CRUD operations work!');
    } else {
      console.log('No organization found for testing');
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
    console.error('Full error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

testAccess();
