﻿// apps/api/src/app.module.ts
import { Module, MiddlewareConsumer, NestModule } from '@nestjs/common';
import { APP_FILTER } from '@nestjs/core';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { HealthController } from './health.controller';
import { PrismaModule } from './shared/prisma/prisma.module';
import { TenantContextMiddleware } from './shared/middleware/tenant-context.middleware';
import { SecurityExceptionFilter } from './shared/filters/security-exception.filter';
import { TestController } from './test.controller';

@Module({
  imports: [PrismaModule],
  controllers: [AppController, HealthController, TestController],
  providers: [
    AppService,
    {
      provide: APP_FILTER,
      useClass: SecurityExceptionFilter,
    },
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(TenantContextMiddleware)
      .forRoutes('*');
  }
}