// apps/api/src/shared/prisma/prisma.service.ts - EXTENSION VERSION
import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

class TenantIsolationViolationError extends Error {
  constructor(message: string) {
    super(`SECURITY VIOLATION: ${message}`);
    this.name = 'TenantIsolationViolationError';
  }
}

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(PrismaService.name);
  
  private readonly TENANT_TABLES = ['User', 'Contact', 'Account', 'Activity'];
  private readonly UNSAFE_ACTIONS = ['findMany', 'updateMany', 'deleteMany'];

  // Extended client with security
  private securedClient: any;

  async onModuleInit() {
    console.log('🔍 Creating secured Prisma client...');
    
    // Create extended client
    this.securedClient = this.$extends({
      query: {
        $allModels: {
          async $allOperations({ model, operation, args, query }: any) {
            console.log(`🔍 [EXTENSION] ${model}.${operation}`);
            
            // Check security rules
            if (model && operation && args) {
              const instance = new PrismaService();
              if (instance.isTenantTable(model) && instance.isUnsafeAction(operation)) {
                if (!instance.hasOrganizationFilter(args)) {
                  console.log(`🔴 [EXTENSION BLOCK] No org filter in ${model}.${operation}`);
                  throw new TenantIsolationViolationError(
                    `${operation} on ${model} requires organizationId filter.`
                  );
                }
              }
            }
            
            return query(args);
          }
        }
      }
    });
    
    await this.$connect();
    this.logger.log('🔒 Prisma Security Extension ACTIVATED');
  }

  async onModuleDestroy() {
    await this.$disconnect();
  }

  // Use the secured client for all operations
  get user() {
    return this.securedClient?.user || super.user;
  }
  
  get contact() {
    return this.securedClient?.contact || super.contact;
  }
  
  get account() {
    return this.securedClient?.account || super.account;
  }
  
  get activity() {
    return this.securedClient?.activity || super.activity;
  }

  private isTenantTable(model: string): boolean {
    return this.TENANT_TABLES.includes(model);
  }

  private isUnsafeAction(action: string): boolean {
    return this.UNSAFE_ACTIONS.includes(action);
  }

  private hasOrganizationFilter(args: any): boolean {
    if (!args?.where) return false;
    
    const where = args.where;
    if (where.organizationId) return true;
    if (where.organization?.id) return true;
    
    if (Array.isArray(where.OR)) {
      return where.OR.some((c: any) => c?.organizationId || c?.organization?.id);
    }
    
    if (Array.isArray(where.AND)) {
      return where.AND.every((c: any) => c?.organizationId || c?.organization?.id);
    }
    
    return false;
  }
}