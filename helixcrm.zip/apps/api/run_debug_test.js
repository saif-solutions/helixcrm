const axios = require('axios');
const https = require('https');

const API_BASE = 'http://localhost:3001/api';
const httpsAgent = new https.Agent({ rejectUnauthorized: false });

async function runDebugTest() {
  console.log('��� DEBUG TEST WITH ENHANCED LOGGING\n');
  
  let cookies = {};
  
  const makeRequest = async (method, url, data = {}) => {
    try {
      const config = {
        method,
        url: `${API_BASE}${url}`,
        headers: {
          'Content-Type': 'application/json',
        },
        httpsAgent,
        withCredentials: true,
        validateStatus: () => true,
      };
      
      if (Object.keys(cookies).length > 0) {
        config.headers.Cookie = Object.entries(cookies)
          .map(([k, v]) => `${k}=${v}`)
          .join('; ');
      }
      
      if (['post', 'put', 'patch'].includes(method.toLowerCase())) {
        config.data = data;
      }
      
      const response = await axios(config);
      
      if (response.headers['set-cookie']) {
        response.headers['set-cookie'].forEach(cookie => {
          const [cookieStr] = cookie.split(';');
          const [name, value] = cookieStr.split('=');
          cookies[name] = value;
        });
      }
      
      return response;
    } catch (error) {
      console.error(`Request failed: ${error.message}`);
      return null;
    }
  };
  
  try {
    // 1. Login
    console.log('1. Logging in...');
    const loginRes = await makeRequest('post', '/auth/login', {
      email: 'test3@example.com',
      password: 'password123'
    });
    
    console.log(`   Status: ${loginRes?.status}`);
    
    if (loginRes?.status !== 200) {
      console.log('Login failed');
      return;
    }
    
    console.log('✅ Login successful\n');
    
    // Wait for logs
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // 2. Try refresh
    console.log('2. Trying refresh...');
    const refreshRes = await makeRequest('post', '/auth/refresh', {});
    
    console.log(`   Refresh status: ${refreshRes?.status}`);
    console.log(`   Message: ${refreshRes?.data?.message}`);
    
    console.log('\n��� Check SERVER CONSOLE for [DEBUG] logs.');
    console.log('We should now see:');
    console.log('   1. What token string is being compared');
    console.log('   2. What hash is in the database');
    console.log('   3. If we enter the error block');
    
  } catch (error) {
    console.error('Test failed:', error.message);
  }
}

runDebugTest();
