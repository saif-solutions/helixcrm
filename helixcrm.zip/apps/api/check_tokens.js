const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function checkTokens() {
  try {
    const user = await prisma.user.findFirst({
      where: { email: { contains: 'test' } },
      select: {
        id: true,
        email: true,
        refreshTokenVersion: true,
        refreshTokenHash: true,
      }
    });
    
    if (user) {
      console.log('User found:', {
        email: user.email,
        refreshTokenVersion: user.refreshTokenVersion,
        versionLength: user.refreshTokenVersion?.length,
        versionPrefix: user.refreshTokenVersion?.substring(0, 20),
        hashExists: !!user.refreshTokenHash,
      });
    } else {
      console.log('No test user found');
    }
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

checkTokens();
