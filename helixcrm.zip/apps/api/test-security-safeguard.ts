// apps/api/test-security-safeguard.ts
import { PrismaService } from './src/shared/prisma/prisma.service';

async function testSecuritySafeguard() {
  console.log('🔒 Testing Prisma Hard Fail Safeguard...\n');
  
  const prisma = new PrismaService();
  
  try {
    await prisma.onModuleInit();
    
    console.log('🟡 Starting security tests...\n');

    // Test 1: This should FAIL - findMany without organizationId
    console.log('🔴 Test 1: Unsafe query WITHOUT organizationId');
    console.log('   Query: prisma.user.findMany({ where: { email: { contains: "test" } } })');
    
    try {
      const unsafeResult = await prisma.user.findMany({
        where: { email: { contains: 'test' } }
      });
      console.log(`❌ TEST 1 FAILED: Query succeeded without organizationId!`);
      console.log(`   Returned ${unsafeResult.length} users (DATA LEAK!)`);
      return false;
    } catch (error: any) {
      if (error.message.includes('SECURITY VIOLATION')) {
        console.log(`✅ TEST 1 PASSED: Safeguard blocked unsafe query`);
        console.log(`   Error: ${error.message.substring(0, 80)}...`);
      } else {
        console.log(`⚠️ TEST 1 UNEXPECTED ERROR: ${error.message}`);
        return false;
      }
    }

    // Test 2: This should FAIL - findMany with empty where
    console.log('\n🔴 Test 2: findMany with EMPTY where clause');
    console.log('   Query: prisma.user.findMany({})');
    
    try {
      const emptyResult = await prisma.user.findMany({});
      console.log(`❌ TEST 2 FAILED: Query succeeded with empty where!`);
      console.log(`   Returned ${emptyResult.length} users (DATA LEAK!)`);
      return false;
    } catch (error: any) {
      if (error.message.includes('SECURITY VIOLATION')) {
        console.log(`✅ TEST 2 PASSED: Safeguard blocked empty where query`);
      } else {
        console.log(`⚠️ TEST 2 UNEXPECTED ERROR: ${error.message}`);
        return false;
      }
    }

    // Test 3: This should WORK - findMany WITH organizationId
    console.log('\n🟢 Test 3: Safe query WITH organizationId');
    
    let org = await prisma.organization.findFirst();  // Changed from const to let
    if (!org) {
      console.log('⚠️ No organizations found, creating test organization...');
      const newOrg = await prisma.organization.create({
        data: {
          name: 'Test Organization',
          slug: 'test-org'
        }
      });
      org = newOrg;
    }
    
    console.log(`   Query: prisma.user.findMany({ where: { organizationId: "${org.id}" } })`);
    
    try {
      const safeResult = await prisma.user.findMany({
        where: { organizationId: org.id }
      });
      console.log(`✅ TEST 3 PASSED: Query with organizationId returned ${safeResult.length} users`);
    } catch (error: any) {
      console.log(`❌ TEST 3 FAILED: Query with organizationId failed: ${error.message}`);
      return false;
    }

    // Test 4: UpdateMany should also be blocked
    console.log('\n🔴 Test 4: updateMany without organizationId');
    console.log('   Query: prisma.user.updateMany({ where: { isActive: true }, data: { lastLoginAt: new Date() } })');
    
    try {
      await prisma.user.updateMany({
        where: { isActive: true },
        data: { lastLoginAt: new Date() }
      });
      console.log('❌ TEST 4 FAILED: updateMany succeeded without organizationId!');
      return false;
    } catch (error: any) {
      if (error.message.includes('SECURITY VIOLATION')) {
        console.log(`✅ TEST 4 PASSED: Safeguard blocked updateMany without organizationId`);
      } else {
        console.log(`⚠️ TEST 4 UNEXPECTED ERROR: ${error.message}`);
        return false;
      }
    }

    console.log('\n🎉 ALL SECURITY TESTS PASSED!');
    console.log('The Prisma Hard Fail Safeguard is working correctly.');
    console.log('✅ Tenant isolation is enforced');
    console.log('✅ Unsafe queries are blocked');
    console.log('✅ Safe queries with organizationId work');
    
    return true;
    
  } catch (error: any) {
    console.error('❌ Test suite failed:', error.message);
    return false;
  } finally {
    await prisma.$disconnect().catch(() => {});
  }
}

// Run the test
testSecuritySafeguard().then(success => {
  if (success) {
    console.log('\n🚀 Security spine is ACTIVE and PROTECTING data');
    process.exit(0);
  } else {
    console.log('\n🔴 SECURITY ISSUE: Safeguard not working correctly!');
    process.exit(1);
  }
});