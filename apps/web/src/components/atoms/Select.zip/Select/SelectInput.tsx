// D:\Projects-In-Hand\helixcrm\apps\web\src\components\atoms\Select\SelectInput.tsx
import * as React from 'react';
import { cn } from '../../../lib/utils';
import { SelectOption } from './Select.types';
import { getSelectClasses, getIconClasses, selectClasses } from './Select.styles';

interface SelectInputProps {
  // Props from main Select
  variant: 'primary' | 'secondary' | 'outline' | 'ghost' | 'filled' | 'minimal';
  size: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  disabled?: boolean;
  loading?: boolean;
  error?: boolean;
  isOpen?: boolean;
  placeholder?: string;
  clearable?: boolean;
  multiple?: boolean;
  selectedOptions?: SelectOption | SelectOption[];
  displayText: string;
  hasCustomRender?: boolean;
  renderValue?: (selected: SelectOption | SelectOption[], displayText: string) => React.ReactNode;
  renderTags?: React.ReactNode;
  className?: string;
  testId?: string;
  selectId: string;
  label?: string;
  required?: boolean;
  helperText?: string;
  errorMessage?: string;
  ariaActiveDescendant?: string;
  
  // Handlers
  onToggle: () => void;
  onClear: (event: React.MouseEvent) => void;
  onKeyDown: (event: React.KeyboardEvent) => void;
  onFocus: (event: React.FocusEvent) => void;
  onBlur: (event: React.FocusEvent) => void;
  
  
  // Ref forwarding
  ref: React.Ref<HTMLDivElement>;
}

export const SelectInput = React.memo(React.forwardRef<HTMLDivElement, SelectInputProps>(
  ({
    variant,
    size,
    disabled = false,
    loading = false,
    error = false,
    isOpen = false,
    placeholder = 'Select an option',
    clearable = false,
    multiple = false,
    selectedOptions,
    displayText,
    hasCustomRender = false,
    renderValue,
    renderTags,
    className,
    testId = 'select',
    selectId,
    label,
    required = false,
    helperText,
    errorMessage,
    ariaActiveDescendant,
    onToggle,
    onClear,
    onKeyDown,
    onFocus,
    onBlur,
  }, ref) => {
    
    const selectedCount = React.useMemo(() => {
      if (!selectedOptions) return 0;
      return Array.isArray(selectedOptions) ? selectedOptions.length : 1;
    }, [selectedOptions]);
    
    const ariaLabel = React.useMemo(() => {
      if (label) return label;
      if (multiple && selectedCount > 0) {
        return `${selectedCount} option${selectedCount > 1 ? 's' : ''} selected`;
      }
      return placeholder || 'Select an option';
    }, [label, multiple, selectedCount, placeholder]);
    
    const hasValue = React.useMemo(() => {
      if (!selectedOptions) return false;
      if (Array.isArray(selectedOptions)) return selectedOptions.length > 0;
      return true;
    }, [selectedOptions]);
    
    // Memoized classes
    const containerClasses = React.useMemo(() => 
      getSelectClasses(variant, size, error, disabled, loading, isOpen, className),
      [variant, size, error, disabled, loading, isOpen, className]
    );
    
    const iconClasses = React.useMemo(() => 
      getIconClasses(size, isOpen),
      [size, isOpen]
    );
    
    return (
      <div className="w-full" data-testid={`${testId}-wrapper`}>
        {/* Label */}
        {label && (
          <label
            id={`${selectId}-label`}
            htmlFor={selectId}
            className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
          >
            {label}
            {required && <span className="text-error-500 ml-1">*</span>}
          </label>
        )}
        
        {/* Select Container */}
        <div
          ref={ref}
          id={selectId}
          className={containerClasses}
          tabIndex={disabled || loading ? -1 : 0}
          role="combobox"
          aria-haspopup="listbox"
          aria-expanded={isOpen}
          aria-labelledby={label ? `${selectId}-label` : undefined}
          aria-describedby={helperText ? `${selectId}-helper` : undefined}
          aria-label={!label ? ariaLabel : undefined}
          aria-activedescendant={ariaActiveDescendant}
          aria-controls={isOpen ? `${testId}-menu` : undefined}
          onClick={onToggle}
          onKeyDown={onKeyDown}
          onFocus={onFocus}
          onBlur={onBlur}
          data-testid={testId}
        >
          {/* Selected Value Display */}
          <div className="flex-1 min-w-0 flex items-center gap-2">
            {hasCustomRender && renderValue && selectedOptions ? (
              renderValue(selectedOptions, displayText)
            ) : (
              <>
                {renderTags || (
                  <span className={cn(
                    selectClasses.utility.truncate,
                    !hasValue
                      ? 'text-gray-500 dark:text-gray-400'
                      : 'text-gray-900 dark:text-gray-100'
                  )}>
                    {displayText}
                  </span>
                )}
              </>
            )}
          </div>
          
          {/* Icons */}
          <div className="flex items-center gap-1">
            {/* Clear Button */}
            {clearable && hasValue && !disabled && !loading && (
              <button
                type="button"
                className={selectClasses.clear.base}
                onClick={onClear}
                aria-label="Clear selection"
                data-testid={`${testId}-clear`}
              >
                <svg className={selectClasses.clear.icon} viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </button>
            )}
            
            {/* Default Chevron */}
            <svg 
              className={iconClasses} 
              viewBox="0 0 20 20" 
              fill="currentColor"
              aria-hidden="true"
            >
              <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </div>
          
          {/* Loading Overlay */}
          {loading && (
            <div className={selectClasses.loading.base}>
              <div className={selectClasses.loading.spinner}>
                <svg className="animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
              </div>
            </div>
          )}
        </div>
        
        {/* Helper Text & Error Message */}
        {(helperText || (error && errorMessage)) && (
          <div 
            id={`${selectId}-helper`}
            className={cn(
              'mt-1 text-sm',
              error ? 'text-error-600 dark:text-error-400' : 'text-gray-500 dark:text-gray-400'
            )}
            data-testid={`${testId}-helper`}
          >
            {error ? errorMessage : helperText}
          </div>
        )}
      </div>
    );
  }
));

SelectInput.displayName = 'SelectInput';