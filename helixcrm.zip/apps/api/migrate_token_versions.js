const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function migrateTokenVersions() {
  console.log('Starting token version migration...\n');
  
  try {
    // Find all users with timestamp-uuid format
    const users = await prisma.user.findMany({
      where: {
        refreshTokenVersion: {
          not: null,
          contains: '-'
        }
      },
      select: {
        id: true,
        email: true,
        refreshTokenVersion: true,
      }
    });
    
    console.log(`Found ${users.length} users with timestamp-uuid format`);
    
    // Strategy: Invalidate all old tokens (force re-login)
    // This is the safest approach for security
    for (const user of users) {
      console.log(`Invalidating tokens for ${user.email}...`);
      
      await prisma.user.update({
        where: { id: user.id },
        data: {
          refreshTokenHash: null,
          refreshTokenVersion: null,
          refreshTokenIssuedAt: null,
          tokenVersion: { increment: 1 }, // Invalidate access tokens too
        }
      });
      
      console.log(`  Cleared old token: ${user.refreshTokenVersion?.substring(0, 30)}...`);
    }
    
    console.log('\n✅ Migration complete!');
    console.log('All users must log in again to get new tokens with jti format.');
    console.log('After login, Bridge will correctly store 64-char hex jti.');
    
  } catch (error) {
    console.error('Migration failed:', error);
  } finally {
    await prisma.$disconnect();
  }
}

migrateTokenVersions();
