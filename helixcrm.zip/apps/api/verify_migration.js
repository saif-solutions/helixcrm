const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function verifyMigration() {
  try {
    const users = await prisma.user.findMany({
      select: {
        email: true,
        refreshTokenVersion: true,
        refreshTokenHash: true,
      }
    });
    
    console.log('Database verification:\n');
    
    let hasLegacyData = false;
    let tokenCount = 0;
    
    users.forEach(user => {
      const version = user.refreshTokenVersion;
      const hasToken = !!user.refreshTokenHash;
      
      if (hasToken) tokenCount++;
      
      if (version && version.includes('-') && version.length > 20) {
        hasLegacyData = true;
        console.log(`❌ ${user.email}: STILL HAS TIMESTAMP-UUID (${version.substring(0, 30)}...)`);
      } else if (version && /^[a-f0-9]{64}$/i.test(version)) {
        console.log(`✅ ${user.email}: CORRECT 64-CHAR HEX JTI`);
      } else if (!version) {
        console.log(`✅ ${user.email}: NULL (no active token)`);
      } else {
        console.log(`⚠️  ${user.email}: UNKNOWN FORMAT (${version?.length} chars)`);
      }
    });
    
    console.log(`\nSummary:`);
    console.log(`- Total users: ${users.length}`);
    console.log(`- Users with active tokens: ${tokenCount}`);
    console.log(`- Legacy data remaining: ${hasLegacyData ? 'YES - PROBLEM' : 'NO - GOOD'}`);
    
    if (!hasLegacyData) {
      console.log('\n��� MIGRATION VERIFIED SUCCESSFULLY!');
      console.log('All legacy timestamp-uuid tokens have been cleared.');
      console.log('Bridge can now work with clean state.');
    } else {
      console.log('\n⚠️  WARNING: Legacy data still exists!');
    }
    
  } catch (error) {
    console.error('Verification failed:', error);
  } finally {
    await prisma.$disconnect();
  }
}

verifyMigration();
