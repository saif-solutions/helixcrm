// apps/api/src/shared/prisma/prisma.module.ts
import { Global, Module, OnModuleInit } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { PrismaSafeguardService } from './prisma-safeguard.service';

@Global()
@Module({
  providers: [PrismaService, PrismaSafeguardService],
  exports: [PrismaService, PrismaSafeguardService],
})
export class PrismaModule implements OnModuleInit {
  constructor(
    private prisma: PrismaService,
    private safeguard: PrismaSafeguardService,
  ) {}

  async onModuleInit() {
    // Install safeguard middleware AFTER PrismaService is initialized
    this.safeguard.installMiddleware(this.prisma);
  }
}