const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function cleanup() {
  console.log('Cleaning up test data from analytics summary tables...\n');
  
  try {
    const [dealCount, revenueCount, pipelineCount, activityCount] = await Promise.all([
      prisma.dealDailySummary.deleteMany({}),
      prisma.revenueDailySummary.deleteMany({}),
      prisma.pipelineStageSummary.deleteMany({}),
      prisma.activityDailySummary.deleteMany({}),
    ]);
    
    console.log('Deleted records:');
    console.log(`  • Deal summaries: ${dealCount.count}`);
    console.log(`  • Revenue summaries: ${revenueCount.count}`);
    console.log(`  • Pipeline stage summaries: ${pipelineCount.count}`);
    console.log(`  • Activity summaries: ${activityCount.count}`);
    
    console.log('\n✅ All test data cleaned up!');
    
  } catch (error) {
    console.error('Error during cleanup:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

cleanup();
