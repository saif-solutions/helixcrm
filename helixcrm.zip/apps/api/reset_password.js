const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');
const prisma = new PrismaClient();

async function resetPassword() {
  try {
    const email = 'admin@acme.com';
    const newPassword = 'TestPassword123!'; // Simple known password
    
    // Hash the password
    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(newPassword, saltRounds);
    
    // Update user
    const user = await prisma.user.update({
      where: { email },
      data: { 
        passwordHash,
        failedLoginAttempts: 0,
        lockedUntil: null,
        lastPasswordChange: new Date(),
        tokenVersion: { increment: 1 }
      }
    });
    
    console.log(`✅ Password reset for ${email}`);
    console.log(`   New password: ${newPassword}`);
    console.log(`   Hash: ${passwordHash.substring(0, 30)}...`);
    console.log(`\nUse these credentials for testing:`);
    console.log(`   Email: ${email}`);
    console.log(`   Password: ${newPassword}`);
    
  } catch (error) {
    console.error('Error resetting password:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

resetPassword();
