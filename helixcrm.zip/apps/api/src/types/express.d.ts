import { TenantUser } from '../shared/tenant/tenant.types';

declare global {
  namespace Express {
    interface Request {
      user?: TenantUser;
      tenantId?: string;
      userId?: string;
    }
  }
}
