// apps/api/src/shared/middleware/tenant-context.middleware.ts
import { Injectable, NestMiddleware, Logger } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class TenantContextMiddleware implements NestMiddleware {
  private readonly logger = new Logger(TenantContextMiddleware.name);

  constructor(private prisma: PrismaService) {}

  async use(req: Request, res: Response, next: NextFunction) {
    try {
      const organizationId = this.extractOrganizationId(req);
      
      if (organizationId) {
        await this.setRLSContext(organizationId, req);
      } else {
        this.logger.warn('No organizationId found in request');
      }
      
      next();
    } catch (error) {
      this.logger.error('Tenant context middleware failed:', error);
      next();
    }
  }

  private extractOrganizationId(req: Request): string | null {
    const user = (req as any).user;
    if (user?.organizationId) return user.organizationId;
    
    if (req.headers['x-organization-id']) {
      return req.headers['x-organization-id'] as string;
    }
    
    const host = req.headers.host;
    if (host) {
      const subdomain = host.split('.')[0];
      if (subdomain && subdomain !== 'www' && subdomain !== 'api') {
        return subdomain;
      }
    }
    
    if (req.query.organizationId && process.env.NODE_ENV !== 'production') {
      return req.query.organizationId as string;
    }
    
    return null;
  }

  private async setRLSContext(organizationId: string, req: Request): Promise<void> {
    try {
      await this.prisma.$executeRawUnsafe(
        `SET app.current_organization_id = '${organizationId}'`
      );
      
      const userId = (req as any).user?.sub;
      if (userId) {
        await this.prisma.$executeRawUnsafe(
          `SET app.current_user_id = '${userId}'`
        );
      }
      
      (req as any).organizationId = organizationId;
      this.logger.debug(`RLS context set for organization: ${organizationId}`);
      
    } catch (error) {
      this.logger.error(`Failed to set RLS context: ${error.message}`);
    }
  }
}