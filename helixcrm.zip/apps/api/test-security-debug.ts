// apps/api/test-security-debug.ts
import { PrismaService } from './src/shared/prisma/prisma.service';

async function testSecurityDebug() {
  console.log('🔒 DEBUGGING Prisma Safeguard\n');
  
  const prisma = new PrismaService();
  
  try {
    await prisma.onModuleInit();
    
    // Clear console for cleaner output
    console.log('\n'.repeat(5));
    
    console.log('='.repeat(60));
    console.log('🔴 TEST 1: findMany without organizationId');
    console.log('='.repeat(60));
    try {
      const result = await prisma.user.findMany({
        where: { email: { contains: 'test' } }
      });
      console.log(`❌ QUERY SUCCEEDED! Returned ${result.length} users`);
      console.log('   THIS IS A DATA LEAK!');
    } catch (error: any) {
      console.log(`✅ Safeguard blocked:`, error.message);
    }
    
    console.log('\n' + '='.repeat(60));
    console.log('🔴 TEST 2: findMany with empty where');
    console.log('='.repeat(60));
    try {
      const result = await prisma.user.findMany({});
      console.log(`❌ QUERY SUCCEEDED! Returned ${result.length} users`);
      console.log('   THIS IS A DATA LEAK!');
    } catch (error: any) {
      console.log(`✅ Safeguard blocked:`, error.message);
    }
    
    console.log('\n' + '='.repeat(60));
    console.log('🟢 TEST 3: findMany WITH organizationId');
    console.log('='.repeat(60));
    const org = await prisma.organization.findFirst();
    if (org) {
      try {
        const result = await prisma.user.findMany({
          where: { organizationId: org.id }
        });
        console.log(`✅ Query succeeded with org filter`);
        console.log(`   Returned ${result.length} users from org ${org.name}`);
      } catch (error: any) {
        console.log(`❌ Query failed:`, error.message);
      }
    }
    
    console.log('\n' + '='.repeat(60));
    console.log('🔴 TEST 4: Test other tenant tables');
    console.log('='.repeat(60));
    try {
      const result = await prisma.contact.findMany({
        where: { email: { contains: 'test' } }
      });
      console.log(`❌ Contact query succeeded! Returned ${result.length} contacts`);
    } catch (error: any) {
      console.log(`✅ Safeguard blocked contacts:`, error.message);
    }
    
  } catch (error: any) {
    console.error('Test suite failed:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

testSecurityDebug();