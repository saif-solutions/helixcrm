const { PrismaClient } = require('@prisma/client');

async function testImplementation() {
  console.log('Testing Analytics Summary Tables Implementation...\n');
  
  const prisma = new PrismaClient();
  
  try {
    console.log('1. Checking if Prisma client has new models...');
    
    // Check if new Prisma models are available
    const hasDealDailySummary = typeof prisma.dealDailySummary !== 'undefined';
    const hasRevenueDailySummary = typeof prisma.revenueDailySummary !== 'undefined';
    const hasPipelineStageSummary = typeof prisma.pipelineStageSummary !== 'undefined';
    const hasActivityDailySummary = typeof prisma.activityDailySummary !== 'undefined';
    
    console.log(`   - dealDailySummary: ${hasDealDailySummary ? '✅ Available' : '❌ Missing'}`);
    console.log(`   - revenueDailySummary: ${hasRevenueDailySummary ? '✅ Available' : '❌ Missing'}`);
    console.log(`   - pipelineStageSummary: ${hasPipelineStageSummary ? '✅ Available' : '❌ Missing'}`);
    console.log(`   - activityDailySummary: ${hasActivityDailySummary ? '✅ Available' : '❌ Missing'}`);
    
    if (!hasDealDailySummary || !hasRevenueDailySummary) {
      console.log('\n⚠️  Some models are missing. Regenerating Prisma client...');
      return;
    }
    
    console.log('\n2. Checking database tables...');
    
    // Try to count records (table might not exist yet)
    try {
      const dealCount = await prisma.dealDailySummary.count();
      console.log(`   - deal_daily_summaries table: ✅ Exists (${dealCount} records)`);
    } catch (error) {
      console.log(`   - deal_daily_summaries table: ❌ Does not exist (${error.message})`);
    }
    
    console.log('\n3. Testing schema compatibility...');
    
    // Test creating a sample record
    const org = await prisma.organization.findFirst();
    
    if (org) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      try {
        // Test if we can create a record
        const testRecord = await prisma.dealDailySummary.create({
          data: {
            organizationId: org.id,
            date: today,
            totalDeals: 0,
            wonDeals: 0,
            lostDeals: 0,
            openDeals: 0,
            totalAmount: 0,
            wonAmount: 0,
            averageDealSize: 0,
            winRate: 0,
            currency: 'USD',
            pipelineId: null,
            stageId: null,
          },
        });
        
        console.log(`   - Create operation: ✅ Success (ID: ${testRecord.id})`);
        
        // Clean up
        await prisma.dealDailySummary.delete({
          where: { id: testRecord.id },
        });
        
        console.log(`   - Delete operation: ✅ Success`);
      } catch (error) {
        console.log(`   - Create operation: ❌ Failed (${error.message})`);
      }
    } else {
      console.log('   - No organization found for testing');
    }
    
    console.log('\n✅ Implementation test completed!');
    
  } catch (error) {
    console.error('❌ Error during test:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

testImplementation();
