const { PrismaClient } = require('@prisma/client');

async function testAuditFixed() {
  const prisma = new PrismaClient();
  
  console.log('��� TESTING AUDIT LOG WITH REAL ORGANIZATION ���');
  
  try {
    // 1. Get a real organization ID
    console.log('\n1️⃣ Finding an organization...');
    const organization = await prisma.organization.findFirst({
      select: { id: true, name: true }
    });
    
    if (!organization) {
      console.log('⚠️  No organizations found, creating a test one...');
      const newOrg = await prisma.organization.create({
        data: {
          name: 'Test Organization',
          slug: 'test-org-' + Date.now()
        }
      });
      organization = newOrg;
    }
    
    console.log(`✅ Using organization: ${organization.name} (${organization.id})`);
    
    // 2. Test creating audit log with real organization
    console.log('\n2️⃣ Creating audit log with real organization...');
    
    const testAuditLog = await prisma.auditLog.create({
      data: {
        action: 'LOGIN_SUCCESS',
        entityType: 'AUTH',
        entityId: 'test-user-123',
        organizationId: organization.id, // REAL ORGANIZATION ID
        actorEmail: 'test@test.com',
        actorType: 'USER',
        severity: 'MEDIUM',
        ipAddress: '127.0.0.1',
        userAgent: 'Test Script',
        metadata: { test: true }
      }
    });
    
    console.log('✅ Audit log created successfully!');
    console.log('   ID:', testAuditLog.id);
    console.log('   Organization:', testAuditLog.organizationId);
    console.log('   Action:', testAuditLog.action);
    console.log('   Actor Type:', testAuditLog.actorType);
    
    // 3. Verify the log
    console.log('\n3️⃣ Verifying enum values...');
    if (testAuditLog.actorType === 'USER' && testAuditLog.action === 'LOGIN_SUCCESS') {
      console.log('✅ Enum values are correct (uppercase)');
    } else {
      console.error('❌ Enum values are incorrect!');
    }
    
    // 4. Test extended action
    console.log('\n4️⃣ Testing extended action...');
    const extendedLog = await prisma.auditLog.create({
      data: {
        action: 'SYSTEM_ERROR',
        entityType: 'SYSTEM',
        organizationId: organization.id,
        actorEmail: 'system@helixcrm',
        actorType: 'SYSTEM',
        severity: 'MEDIUM',
        metadata: {
          _extendedAction: 'ROLE_CREATED',
          _originalAction: 'ROLE_CREATED',
          roleName: 'Test Role'
        }
      }
    });
    
    console.log('✅ Extended action log created');
    
    // 5. Clean up test logs (keep organization)
    console.log('\n5️⃣ Cleaning up test logs...');
    await prisma.auditLog.deleteMany({
      where: {
        OR: [
          { id: testAuditLog.id },
          { id: extendedLog.id }
        ]
      }
    });
    
    console.log('✅ Test logs cleaned up');
    
    // 6. Final check
    console.log('\n6️⃣ Final verification...');
    const totalLogs = await prisma.auditLog.count();
    console.log(`��� Total audit logs: ${totalLogs}`);
    
    // Check for any lowercase values
    const lowercaseCheck = await prisma.$queryRaw`
      SELECT 
        COUNT(CASE WHEN "actorType" IN ('user', 'system') THEN 1 END) as lowercase_actor,
        COUNT(CASE WHEN LOWER(action) = action THEN 1 END) as lowercase_action,
        COUNT(CASE WHEN LOWER("entityType") = "entityType" THEN 1 END) as lowercase_entity,
        COUNT(CASE WHEN LOWER(severity) = severity THEN 1 END) as lowercase_severity
      FROM audit_logs
    `;
    
    const hasLowercase = Object.values(lowercaseCheck[0]).some(count => count > 0);
    
    if (!hasLowercase) {
      console.log('✅ No lowercase enum values in database!');
    } else {
      console.error('❌ Found lowercase values:', lowercaseCheck[0]);
    }
    
    console.log('\n��� AUDIT LOG SYSTEM IS WORKING CORRECTLY! ���');
    console.log('✅ Foreign key constraints satisfied');
    console.log('✅ ENUM values are uppercase');
    console.log('✅ Database schema is correct');
    
  } catch (error) {
    console.error('\n❌ TEST FAILED:', error.message);
    if (error.code === 'P2003') {
      console.error('��� Foreign key violation! Need to use real organizationId');
      console.error('   Check that organization exists in organizations table');
    }
  } finally {
    await prisma.$disconnect();
  }
}

testAuditFixed();
