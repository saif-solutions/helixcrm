// Simple test to verify analytics summary service
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function testAnalyticsSummary() {
  console.log('Testing analytics summary tables...\n');
  
  try {
    // 1. Check if summary tables exist
    const tableCount = await prisma.$queryRaw`
      SELECT COUNT(*) as table_count
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
        AND table_name IN (
          'deal_daily_summaries',
          'revenue_daily_summaries', 
          'pipeline_stage_summaries',
          'activity_daily_summaries'
        )
    `;
    
    console.log('Table count result:', tableCount);
    
    // 2. Try to create a test summary
    const organizations = await prisma.organization.findFirst();
    
    if (organizations) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      // Test DealDailySummary
      const testSummary = await prisma.dealDailySummary.create({
        data: {
          organizationId: organizations.id,
          date: today,
          totalDeals: 10,
          wonDeals: 5,
          lostDeals: 2,
          openDeals: 3,
          totalAmount: 100000,
          wonAmount: 50000,
          averageDealSize: 10000,
          winRate: 50,
          currency: 'USD',
          pipelineId: null,
          stageId: null,
        },
      });
      
      console.log('Created test summary:', testSummary.id);
      
      // Clean up
      await prisma.dealDailySummary.delete({
        where: { id: testSummary.id },
      });
      
      console.log('Test summary cleaned up');
    } else {
      console.log('No organizations found for testing');
    }
    
    console.log('\n✅ Analytics summary tables test passed!');
    
  } catch (error) {
    console.error('❌ Error testing analytics summary tables:', error.message);
    console.error('Full error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

testAnalyticsSummary();
