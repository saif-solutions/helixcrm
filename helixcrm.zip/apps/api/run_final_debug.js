const axios = require('axios');
const https = require('https');

const API_BASE = 'http://localhost:3001/api';
const httpsAgent = new https.Agent({ rejectUnauthorized: false });

async function runFinalDebug() {
  console.log('��� FINAL DEBUG TEST - CHECKING BRIDGE LOGS\n');
  
  let cookies = {};
  
  const makeRequest = async (method, url, data = {}) => {
    try {
      const config = {
        method,
        url: `${API_BASE}${url}`,
        headers: {
          'Content-Type': 'application/json',
        },
        httpsAgent,
        withCredentials: true,
        validateStatus: () => true,
      };
      
      if (Object.keys(cookies).length > 0) {
        config.headers.Cookie = Object.entries(cookies)
          .map(([k, v]) => `${k}=${v}`)
          .join('; ');
      }
      
      if (['post', 'put', 'patch'].includes(method.toLowerCase())) {
        config.data = data;
      }
      
      const response = await axios(config);
      
      if (response.headers['set-cookie']) {
        response.headers['set-cookie'].forEach(cookie => {
          const [cookieStr] = cookie.split(';');
          const [name, value] = cookieStr.split('=');
          cookies[name] = value;
        });
      }
      
      return response;
    } catch (error) {
      console.error(`Request failed: ${error.message}`);
      return null;
    }
  };
  
  try {
    // 1. Login to get fresh tokens
    console.log('1. Logging in to get fresh tokens...');
    const loginRes = await makeRequest('post', '/auth/login', {
      email: 'test3@example.com',
      password: 'password123'
    });
    
    console.log(`   Status: ${loginRes?.status}`);
    
    if (loginRes?.status !== 200) {
      console.log('Login failed');
      return;
    }
    
    console.log('✅ Login successful');
    console.log('   Check SERVER CONSOLE for AuthService [DEBUG] logs\n');
    
    // Wait for logs to flush
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // 2. Try refresh - this will trigger Bridge debug logs
    console.log('2. Trying refresh (will show Bridge debug logs)...');
    const refreshRes = await makeRequest('post', '/auth/refresh', {});
    
    console.log(`   Refresh status: ${refreshRes?.status}`);
    console.log(`   Message: ${refreshRes?.data?.message}`);
    
    console.log('\n��� CHECK SERVER CONSOLE FOR THESE LOGS:');
    console.log('   1. [DEBUG] Refresh token validation - shows JWT jti vs DB jti');
    console.log('   2. [BRIDGE-DEBUG] findRefreshToken called - shows lookup JTI');
    console.log('   3. [BRIDGE-DEBUG] Database query result - shows if token found');
    console.log('   4. [DEBUG] Hash comparison result - shows bcrypt compare result');
    
    console.log('\n��� CRITICAL COMPARISONS TO CHECK:');
    console.log('   • Does JWT jti match DB refreshTokenVersion?');
    console.log('   • Does Bridge receive the correct JTI?');
    console.log('   • Does Bridge find the user in database?');
    console.log('   • What does bcrypt.compare return?');
    
  } catch (error) {
    console.error('Test failed:', error.message);
  }
}

runFinalDebug();
