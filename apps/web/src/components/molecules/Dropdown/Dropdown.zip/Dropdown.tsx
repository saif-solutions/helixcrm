// D:\Projects-In-Hand\helixcrm\apps\web\src\components\molecules\Dropdown\Dropdown.tsx
import * as React from 'react';
import * as DropdownPrimitive from '@radix-ui/react-dropdown-menu';
import { cn } from '../../../lib/utils';
import {
  DropdownProps,
  DropdownRef,
  DropdownItemProps,
  DropdownGroupProps,
  DropdownSeparatorProps,
  DropdownLabelProps,
  DropdownShortcutProps,
  DropdownEvent,
} from './Dropdown.types'; // Removed unused DropdownPlacement import
import {
  dropdownTokens,
  dropdownClasses,
  dropdownZIndexClasses,
  defaultDropdownStyleProps,
} from './Dropdown.styles';
import {
  createNormalizedDropdownEvent,
  generateDropdownIds,
  createDefaultDropdownItems,
} from './Dropdown.utils';

// ============================================================================
// 1. DROPDOWN CONTEXT
// ============================================================================

interface DropdownContextValue {
  size: NonNullable<DropdownProps['size']>;
  closeOnSelect: boolean;
  open: boolean;
  onOpenChange: (open: boolean, event?: DropdownEvent) => void;
  portalContainer: HTMLElement | null;
  transitionDuration: number;
  ids: {
    dropdownId: string;
    triggerId: string;
    contentId: string;
    labelId?: string;
  };
}

const DropdownContext = React.createContext<DropdownContextValue | undefined>(
  undefined
);

const useDropdownContext = () => {
  const context = React.useContext(DropdownContext);
  if (!context) {
    throw new Error(
      'Dropdown components must be used within a Dropdown.Root'
    );
  }
  return context;
};

// ============================================================================
// 2. TYPE DEFINITIONS FOR COMPOUND COMPONENTS
// ============================================================================

// Define the main component type with compound components attached
interface DropdownComponent extends React.ForwardRefExoticComponent<DropdownProps & React.RefAttributes<DropdownRef>> {
  Item: React.ForwardRefExoticComponent<DropdownItemProps & React.RefAttributes<HTMLDivElement>>;
  Group: React.ForwardRefExoticComponent<DropdownGroupProps & React.RefAttributes<HTMLDivElement>>;
  Separator: React.ForwardRefExoticComponent<DropdownSeparatorProps & React.RefAttributes<HTMLHRElement>>;
  Label: React.ForwardRefExoticComponent<DropdownLabelProps & React.RefAttributes<HTMLDivElement>>;
  Shortcut: React.ForwardRefExoticComponent<DropdownShortcutProps & React.RefAttributes<HTMLSpanElement>>;
  CheckboxItem: React.ForwardRefExoticComponent<DropdownItemProps & React.RefAttributes<HTMLDivElement> & { value?: string }>;
  RadioItem: React.ForwardRefExoticComponent<DropdownItemProps & React.RefAttributes<HTMLDivElement> & { value: string }>;
  SubMenu: React.ForwardRefExoticComponent<DropdownSubMenuProps & React.RefAttributes<HTMLDivElement>>;
  createDefaultItems: typeof createDefaultDropdownItems;
}

interface DropdownSubMenuProps {
  trigger: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  'data-testid'?: string;
}

// ============================================================================
// 3. MAIN DROPDOWN COMPONENT
// ============================================================================

const DropdownRoot = React.forwardRef<DropdownRef, DropdownProps>(
  (props, ref) => {
    // ========================================================================
    // 3.1 DESTRUCTURE PROPS WITH DEFAULTS
    // ========================================================================
    const {
      // Core properties
      open: controlledOpen,
      onOpenChange,
      defaultOpen = false,
      
      // Content properties
      trigger,
      children,
      items = [],
      groups = [],
      
      // Visual properties
      size = 'md',
      placement = 'bottom-start',
      animation = 'scale',
      overlay = false,
      overlayClassName = '',
      overlayOpacity = 0.5,
      overlayBlur = true,
      overlayColor = 'black',
      
      // Behavior properties
      closeOnSelect = true,
      closeOnEscape = true,
      closeOnOutsideClick = true,
      closeOnScroll = false,
      preventScroll = false,
      lockFocus = true,
      autoFocus = false,
      modal = true,
      persistent = false,
      
      // Positioning properties
      offset = defaultDropdownStyleProps.offset,
      skidding = defaultDropdownStyleProps.skidding,
      boundaryPadding = defaultDropdownStyleProps.boundaryPadding,
      collisionBoundary,
      collisionPadding = defaultDropdownStyleProps.collisionPadding,
      strategy = 'absolute',
      
      // Trigger properties
      triggerAsChild = true,
      triggerClassName = '',
      triggerDisabled = false,
      
      // Content properties
      contentClassName = '',
      contentStyle = {},
      maxHeight = defaultDropdownStyleProps.maxHeight,
      minWidth = defaultDropdownStyleProps.minWidth,
      maxWidth,
      
      // Portal properties
      portal = true,
      portalContainer = null,
      portalClassName = '',
      
      // Transition properties
      transitionDuration = defaultDropdownStyleProps.transitionDuration,
      transitionTimingFunction = 'ease-out',
      unmountOnExit = true,
      
      // Styling
      className = '',
      style = {},
      
      // Testing & analytics
      'data-testid': dataTestId = 'dropdown',
      'data-analytics': dataAnalytics,
      'data-cy': dataCy,
      
      // Accessibility
      ariaLabel,
      ariaLabelledby,
      ariaDescribedby,
      role = 'menu',
      
      // Other HTML props
      ...restProps
    } = props;

    // Filter out the 'dir' prop if it exists to avoid conflicts with Radix
    const { dir, ...filteredRestProps } = restProps as any;

    // ========================================================================
    // 3.2 STATE & REFS
    // ========================================================================
    const [internalOpen, setInternalOpen] = React.useState(defaultOpen);
    const isControlled = controlledOpen !== undefined;
    const open = isControlled ? controlledOpen : internalOpen;
    
    const triggerRef = React.useRef<HTMLDivElement>(null);
    const contentRef = React.useRef<HTMLDivElement>(null);
    
    // Generate unique IDs for accessibility
    const ids = React.useMemo(() => generateDropdownIds(dataTestId), [dataTestId]);

    // ========================================================================
    // 3.3 EVENT HANDLER
    // ========================================================================
    const handleOpenChange = React.useCallback(
      (newOpen: boolean, event?: DropdownEvent) => {
        if (!isControlled) {
          setInternalOpen(newOpen);
        }
        
        // Call user-provided handler with normalized event
        if (onOpenChange) {
          const normalizedEvent = event ? createNormalizedDropdownEvent(event) : undefined;
          onOpenChange(newOpen, normalizedEvent);
        }
      },
      [isControlled, onOpenChange]
    );

    // ========================================================================
    // 3.4 REF API IMPLEMENTATION
    // ========================================================================
    React.useImperativeHandle(
      ref,
      () => ({
        open: () => handleOpenChange(true),
        close: () => handleOpenChange(false),
        toggle: () => handleOpenChange(!open),
        focusFirstItem: () => {
          if (contentRef.current) {
            const firstItem = contentRef.current.querySelector<HTMLElement>(
              '[role="menuitem"]:not([disabled]), [role="menuitemradio"]:not([disabled]), [role="menuitemcheckbox"]:not([disabled])'
            );
            firstItem?.focus();
          }
        },
        focusLastItem: () => {
          if (contentRef.current) {
            const items = contentRef.current.querySelectorAll<HTMLElement>(
              '[role="menuitem"]:not([disabled]), [role="menuitemradio"]:not([disabled]), [role="menuitemcheckbox"]:not([disabled])'
            );
            items[items.length - 1]?.focus();
          }
        },
        updatePosition: () => {
          if (contentRef.current) {
            const event = new CustomEvent('dropdown-position-update');
            contentRef.current.dispatchEvent(event);
          }
        },
        isOpen: () => open,
        getTrigger: () => triggerRef.current,
      }),
      [open, handleOpenChange]
    );

    // ========================================================================
    // 3.5 CONTEXT VALUE
    // ========================================================================
    const contextValue: DropdownContextValue = React.useMemo(
      () => ({
        size,
        closeOnSelect,
        open,
        onOpenChange: handleOpenChange,
        portalContainer,
        transitionDuration,
        ids,
      }),
      [size, closeOnSelect, open, handleOpenChange, portalContainer, transitionDuration, ids]
    );

    // ========================================================================
    // 3.6 HELPER FUNCTIONS
    // ========================================================================
    const handleRadixOpenChange = React.useCallback((newOpen: boolean) => {
      handleOpenChange(newOpen);
    }, [handleOpenChange]);

    // Map our placement to Radix's side and align
    const getRadixPlacement = () => {
      const [side, align] = placement.split('-');
      return {
        side: side as 'top' | 'bottom' | 'left' | 'right',
        align: align as 'start' | 'center' | 'end' | undefined
      };
    };

    const { side, align } = getRadixPlacement();

    // Build portal container class
    const portalClass = cn(
      dropdownClasses.portal.base,
      portalClassName,
      dropdownZIndexClasses.dropdown
    );

    // Build overlay class
    const overlayClass = cn(
      'fixed inset-0',
      overlayBlur ? dropdownTokens.backdrop.md : '',
      overlayClassName
    );

    // Handle items/groups props
    const renderContentFromProps = () => {
      if (children) return children;
      
      const allItems = [...items];
      const allGroups = [...groups];
      
      return (
        <React.Fragment>
          {allGroups.map((group, groupIndex) => (
            <DropdownGroup
              key={group.id || `group-${groupIndex}`}
              label={group.label}
              data-testid={group['data-testid']}
            >
              {group.items.map((item, itemIndex) => {
                // Create a wrapper function that matches onSelect type
                const handleItemSelect = (event?: DropdownEvent) => {
                  if (item.onClick) {
                    item.onClick(event);
                  }
                };
                
                return (
                  <DropdownItem
                    key={item.id || `item-${groupIndex}-${itemIndex}`}
                    variant={item.variant}
                    disabled={item.disabled}
                    loading={item.loading}
                    checked={item.checked}
                    shortcut={item.shortcut}
                    icon={item.icon}
                    onSelect={handleItemSelect}
                    data-testid={item['data-testid']}
                    data-analytics={item['data-analytics']}
                  >
                    {item.label}
                  </DropdownItem>
                );
              })}
            </DropdownGroup>
          ))}
          
          {allItems.map((item, index) => {
            // Create a wrapper function that matches onSelect type
            const handleItemSelect = (event?: DropdownEvent) => {
              if (item.onClick) {
                item.onClick(event);
              }
            };
            
            return (
              <DropdownItem
                key={item.id || `item-${index}`}
                variant={item.variant}
                disabled={item.disabled}
                loading={item.loading}
                checked={item.checked}
                shortcut={item.shortcut}
                icon={item.icon}
                onSelect={handleItemSelect}
                data-testid={item['data-testid']}
                data-analytics={item['data-analytics']}
              >
                {item.label}
              </DropdownItem>
            );
          })}
        </React.Fragment>
      );
    };

    return (
      <DropdownContext.Provider value={contextValue}>
        <DropdownPrimitive.Root
          open={open}
          onOpenChange={handleRadixOpenChange}
          defaultOpen={defaultOpen}
          modal={modal}
          data-testid={dataTestId}
          data-analytics={dataAnalytics}
          data-cy={dataCy}
          {...filteredRestProps}
        >
          <DropdownPrimitive.Trigger asChild={triggerAsChild}>
            <div
              className={cn(
                dropdownClasses.trigger.base,
                triggerClassName,
                triggerDisabled ? dropdownClasses.trigger.disabled : ''
              )}
              ref={triggerRef}
              aria-disabled={triggerDisabled}
              id={ids.triggerId}
              aria-haspopup="menu"
              aria-expanded={open}
              data-testid={`${dataTestId}-trigger`}
            >
              {trigger}
            </div>
          </DropdownPrimitive.Trigger>

          {portal ? (
            <DropdownPrimitive.Portal container={portalContainer}>
              <div className={portalClass}>
                {/* Custom overlay */}
                {overlay && open && modal && (
                  <div
                    className={overlayClass}
                    style={{
                      backgroundColor: overlayColor,
                      opacity: overlayOpacity,
                      zIndex: dropdownTokens.zIndex.overlay,
                    }}
                    data-testid={`${dataTestId}-overlay`}
                  />
                )}

                {/* Content */}
                <DropdownPrimitive.Content
                  ref={contentRef}
                  className={cn(
                    dropdownClasses.content.base,
                    dropdownClasses.content.size[size],
                    contentClassName,
                    dropdownClasses.animation[animation]?.enter,
                    dropdownClasses.accessibility.reducedMotion
                  )}
                  style={{
                    ...contentStyle,
                    maxHeight,
                    minWidth,
                    maxWidth,
                    zIndex: dropdownTokens.zIndex.dropdown,
                    animationDuration: `${transitionDuration}ms`,
                    animationTimingFunction: transitionTimingFunction,
                  }}
                  side={side}
                  sideOffset={offset}
                  align={align}
                  alignOffset={skidding}
                  collisionBoundary={collisionBoundary as Element | Element[] | undefined}
                  collisionPadding={collisionPadding}
                  sticky="partial"
                  hideWhenDetached={!persistent}
                  loop={lockFocus}
                  onEscapeKeyDown={(e: Event) => {
                    if (!closeOnEscape) e.preventDefault();
                  }}
                  onInteractOutside={(e: Event) => {
                    if (!closeOnOutsideClick && !overlay) e.preventDefault();
                  }}
                  onCloseAutoFocus={(e: Event) => {
                    if (!autoFocus) e.preventDefault();
                  }}
                  onFocusOutside={(e: Event) => {
                    if (persistent) e.preventDefault();
                  }}
                  forceMount={unmountOnExit ? undefined : true}
                  aria-label={ariaLabel}
                  aria-labelledby={ariaLabelledby || ids.triggerId}
                  aria-describedby={ariaDescribedby}
                  role={role}
                  data-testid={`${dataTestId}-content`}
                >
                  {renderContentFromProps()}
                </DropdownPrimitive.Content>
              </div>
            </DropdownPrimitive.Portal>
          ) : (
            // Non-portal version
            open && (
              <DropdownPrimitive.Content
                ref={contentRef}
                className={cn(
                  dropdownClasses.content.base,
                  dropdownClasses.content.size[size],
                  contentClassName,
                  dropdownClasses.animation[animation]?.enter
                )}
                style={{
                  ...contentStyle,
                  maxHeight,
                  minWidth,
                  maxWidth,
                  position: 'absolute',
                  zIndex: dropdownTokens.zIndex.dropdown,
                }}
                side={side}
                sideOffset={offset}
                align={align}
                alignOffset={skidding}
                collisionBoundary={collisionBoundary as Element | Element[] | undefined}
                collisionPadding={collisionPadding}
                sticky="partial"
                hideWhenDetached={!persistent}
                loop={lockFocus}
                data-testid={`${dataTestId}-content`}
              >
                {renderContentFromProps()}
              </DropdownPrimitive.Content>
            )
          )}
        </DropdownPrimitive.Root>
      </DropdownContext.Provider>
    );
  }
);

DropdownRoot.displayName = 'Dropdown';

// ============================================================================
// 4. COMPOUND COMPONENTS
// ============================================================================

// 4.1 Dropdown.Item
const DropdownItem = React.forwardRef<HTMLDivElement, DropdownItemProps>(
  (props, ref) => {
    const {
      children,
      variant = 'default',
      disabled = false,
      loading = false,
      checked = false,
      shortcut,
      icon,
      iconPosition = 'left',
      onSelect,
      className = '',
      'data-testid': dataTestId = 'dropdown-item',
      'data-analytics': dataAnalytics,
      ...restProps
    } = props;

    const context = useDropdownContext();

    const handleSelect = React.useCallback(
      (event: Event) => {
        if (disabled || loading) {
          event.preventDefault();
          return;
        }

        if (onSelect) {
          onSelect(event as DropdownEvent);
        }

        if (context.closeOnSelect) {
          context.onOpenChange(false, event as DropdownEvent);
        }
      },
      [disabled, loading, onSelect, context]
    );

    const itemClass = cn(
      dropdownClasses.item.base,
      dropdownClasses.item.variant[variant],
      dropdownClasses.item.highlighted(variant),
      className,
      disabled ? dropdownTokens.colors.action.disabled : '',
      loading ? dropdownTokens.colors.action.loading : ''
    );

    return (
      <DropdownPrimitive.Item
        ref={ref}
        className={itemClass}
        disabled={disabled || loading}
        onSelect={handleSelect}
        data-testid={dataTestId}
        data-analytics={dataAnalytics}
        {...restProps}
      >
        {checked && (
          <DropdownPrimitive.ItemIndicator
            className={dropdownClasses.item.check}
          >
            <span className="h-2 w-2 rounded-full bg-current" />
          </DropdownPrimitive.ItemIndicator>
        )}

        {icon && iconPosition === 'left' && (
          <span className={cn(dropdownClasses.item.icon.base, dropdownClasses.item.icon.position.left)}>
            {icon}
          </span>
        )}

        <span className={dropdownClasses.item.label}>{children}</span>

        {icon && iconPosition === 'right' && (
          <span className={cn(dropdownClasses.item.icon.base, dropdownClasses.item.icon.position.right)}>
            {icon}
          </span>
        )}

        {shortcut && (
          <span className={dropdownClasses.item.shortcut}>{shortcut}</span>
        )}
      </DropdownPrimitive.Item>
    );
  }
);

DropdownItem.displayName = 'Dropdown.Item';

// 4.2 Dropdown.Group
const DropdownGroup = React.forwardRef<HTMLDivElement, DropdownGroupProps>(
  (props, ref) => {
    const {
      children,
      label,
      className = '',
      'data-testid': dataTestId = 'dropdown-group',
      ...restProps
    } = props;

    return (
      <DropdownPrimitive.Group
        ref={ref}
        className={cn(dropdownClasses.group.base, className)}
        data-testid={dataTestId}
        {...restProps}
      >
        {label && (
          <DropdownPrimitive.Label className={dropdownClasses.group.label}>
            {label}
          </DropdownPrimitive.Label>
        )}
        {children}
      </DropdownPrimitive.Group>
    );
  }
);

DropdownGroup.displayName = 'Dropdown.Group';

// 4.3 Dropdown.Separator
const DropdownSeparator = React.forwardRef<HTMLHRElement, DropdownSeparatorProps>(
  (props, ref) => {
    const {
      className = '',
      'data-testid': dataTestId = 'dropdown-separator',
      ...restProps
    } = props;

    return (
      <DropdownPrimitive.Separator
        ref={ref}
        className={cn(dropdownClasses.separator.base, className)}
        data-testid={dataTestId}
        {...restProps}
      />
    );
  }
);

DropdownSeparator.displayName = 'Dropdown.Separator';

// 4.4 Dropdown.Label
const DropdownLabel = React.forwardRef<HTMLDivElement, DropdownLabelProps>(
  (props, ref) => {
    const {
      children,
      className = '',
      'data-testid': dataTestId = 'dropdown-label',
      ...restProps
    } = props;

    return (
      <DropdownPrimitive.Label
        ref={ref}
        className={cn(dropdownClasses.label.base, className)}
        data-testid={dataTestId}
        {...restProps}
      >
        {children}
      </DropdownPrimitive.Label>
    );
  }
);

DropdownLabel.displayName = 'Dropdown.Label';

// 4.5 Dropdown.Shortcut
const DropdownShortcut = React.forwardRef<HTMLSpanElement, DropdownShortcutProps>(
  (props, ref) => {
    const {
      children,
      className = '',
      'data-testid': dataTestId = 'dropdown-shortcut',
      ...restProps
    } = props;

    return (
      <span
        ref={ref}
        className={cn(dropdownClasses.item.shortcut, className)}
        data-testid={dataTestId}
        {...restProps}
      >
        {children}
      </span>
    );
  }
);

DropdownShortcut.displayName = 'Dropdown.Shortcut';

// 4.6 Dropdown.CheckboxItem
interface CheckboxItemProps extends Omit<DropdownItemProps, 'checked'> {
  value?: string;
}

const DropdownCheckboxItem = React.forwardRef<HTMLDivElement, CheckboxItemProps>(
  (props, ref) => {
    const {
      children,
      disabled = false,
      onSelect,
      className = '',
      'data-testid': dataTestId = 'dropdown-checkbox-item',
      value,
      ...restProps
    } = props;

    const context = useDropdownContext();

    const handleSelect = React.useCallback(
      (event: Event) => {
        if (disabled) {
          event.preventDefault();
          return;
        }

        if (onSelect) {
          onSelect(event as DropdownEvent);
        }

        if (context.closeOnSelect) {
          context.onOpenChange(false, event as DropdownEvent);
        }
      },
      [disabled, onSelect, context]
    );

    return (
      <DropdownPrimitive.CheckboxItem
        ref={ref}
        className={cn(dropdownClasses.checkboxItem.base, className)}
        disabled={disabled}
        onSelect={handleSelect}
        data-testid={dataTestId}
        {...restProps}
      >
        <DropdownPrimitive.ItemIndicator className={dropdownClasses.checkboxItem.indicator}>
          <span className="h-2 w-2 rounded-sm bg-current" />
        </DropdownPrimitive.ItemIndicator>
        {children}
      </DropdownPrimitive.CheckboxItem>
    );
  }
);

DropdownCheckboxItem.displayName = 'Dropdown.CheckboxItem';

// 4.7 Dropdown.RadioItem
interface RadioItemProps extends Omit<DropdownItemProps, 'checked'> {
  value: string;
}

const DropdownRadioItem = React.forwardRef<HTMLDivElement, RadioItemProps>(
  (props, ref) => {
    const {
      children,
      disabled = false,
      onSelect,
      className = '',
      'data-testid': dataTestId = 'dropdown-radio-item',
      value,
      ...restProps
    } = props;

    const context = useDropdownContext();

    const handleSelect = React.useCallback(
      (event: Event) => {
        if (disabled) {
          event.preventDefault();
          return;
        }

        if (onSelect) {
          onSelect(event as DropdownEvent);
        }

        if (context.closeOnSelect) {
          context.onOpenChange(false, event as DropdownEvent);
        }
      },
      [disabled, onSelect, context]
    );

    return (
      <DropdownPrimitive.RadioItem
        ref={ref}
        className={cn(dropdownClasses.radioItem.base, className)}
        disabled={disabled}
        onSelect={handleSelect}
        value={value}
        data-testid={dataTestId}
        {...restProps}
      >
        <DropdownPrimitive.ItemIndicator className={dropdownClasses.radioItem.indicator}>
          <span className="h-2 w-2 rounded-full bg-current" />
        </DropdownPrimitive.ItemIndicator>
        {children}
      </DropdownPrimitive.RadioItem>
    );
  }
);

DropdownRadioItem.displayName = 'Dropdown.RadioItem';

// 4.8 Dropdown.SubMenu
const DropdownSubMenu = React.forwardRef<HTMLDivElement, DropdownSubMenuProps>(
  (props, ref) => {
    const {
      trigger,
      children,
      className = '',
      'data-testid': dataTestId = 'dropdown-submenu',
    } = props;

    return (
      <DropdownPrimitive.Sub>
        <DropdownPrimitive.SubTrigger
          ref={ref}
          className={cn(dropdownClasses.subMenu.trigger, className)}
          data-testid={dataTestId}
        >
          {trigger}
          <span className={dropdownClasses.subMenu.icon}>▶</span>
        </DropdownPrimitive.SubTrigger>
        <DropdownPrimitive.Portal>
          <DropdownPrimitive.SubContent
            className={cn(
              dropdownClasses.content.base,
              dropdownClasses.content.size.md
            )}
            sideOffset={8}
            alignOffset={-4}
          >
            {children}
          </DropdownPrimitive.SubContent>
        </DropdownPrimitive.Portal>
      </DropdownPrimitive.Sub>
    );
  }
);

DropdownSubMenu.displayName = 'Dropdown.SubMenu';

// ============================================================================
// 5. CREATE THE COMPOUND COMPONENT
// ============================================================================

export const Dropdown = Object.assign(DropdownRoot, {
  Item: DropdownItem,
  Group: DropdownGroup,
  Separator: DropdownSeparator,
  Label: DropdownLabel,
  Shortcut: DropdownShortcut,
  CheckboxItem: DropdownCheckboxItem,
  RadioItem: DropdownRadioItem,
  SubMenu: DropdownSubMenu,
  createDefaultItems: createDefaultDropdownItems,
}) as DropdownComponent;

// ============================================================================
// 6. EXPORT TYPES
// ============================================================================

export type {
  DropdownProps,
  DropdownRef,
  DropdownItemProps,
  DropdownGroupProps,
  DropdownSeparatorProps,
  DropdownLabelProps,
  DropdownShortcutProps,
};

export { createDefaultDropdownItems };