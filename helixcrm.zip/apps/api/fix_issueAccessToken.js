const fs = require('fs');
const path = require('path');

const filePath = path.resolve(__dirname, 'src/modules/auth/auth.service.ts');
let content = fs.readFileSync(filePath, 'utf8', 'utf8');

console.log('Current issueAccessToken occurrences:', (content.match(/\.issueAccessToken/g) || []).length);

// Fix line 211: .tokenManager.issueAccessToken → .jwt.issueToken
// And fix payload to match JwtService expectations
content = content.replace(
  /const accessToken = await this\.authCoreAdapter\s*\.tokenManager\s*\.issueAccessToken\(\s*\{/,
  `const accessToken = await this.authCoreAdapter.jwt.issueToken({`
);

// Fix line 517: .tokenManager.issueAccessToken → .jwt.issueToken
content = content.replace(
  /const newAccessToken = await this\.authCoreAdapter\s*\.tokenManager\s*\.issueAccessToken\(\s*\{/,
  `const newAccessToken = await this.authCoreAdapter.jwt.issueToken({`
);

console.log('After fix - issueAccessToken occurrences:', (content.match(/\.issueAccessToken/g) || []).length);

// Write back
fs.writeFileSync(filePath, content, 'utf8');
console.log('✅ File updated');
