const axios = require('axios');
const https = require('https');
const { PrismaClient } = require('@prisma/client');

const API_BASE = 'http://localhost:3001/api';
const httpsAgent = new https.Agent({ rejectUnauthorized: false });

async function debugRefresh() {
  console.log('��� DEBUGGING REFRESH TOKEN ISSUE\n');
  
  const prisma = new PrismaClient();
  let cookies = {};
  
  // Proper request helper
  const makeRequest = async (method, url, data = {}) => {
    try {
      const config = {
        method,
        url: `${API_BASE}${url}`,
        headers: {
          'Content-Type': 'application/json',
        },
        httpsAgent,
        withCredentials: true,
        validateStatus: () => true,
      };
      
      if (Object.keys(cookies).length > 0) {
        config.headers.Cookie = Object.entries(cookies)
          .map(([k, v]) => `${k}=${v}`)
          .join('; ');
      }
      
      if (['post', 'put', 'patch'].includes(method.toLowerCase()) && data) {
        config.data = data;
      }
      
      const response = await axios(config);
      
      if (response.headers['set-cookie']) {
        response.headers['set-cookie'].forEach(cookie => {
          const [cookieStr] = cookie.split(';');
          const [name, value] = cookieStr.split('=');
          cookies[name] = value;
        });
      }
      
      return response;
    } catch (error) {
      console.error(`Request failed: ${error.message}`);
      return null;
    }
  };
  
  try {
    // 1. Login
    console.log('1. Logging in...');
    const loginRes = await makeRequest('post', '/auth/login', {
      email: 'test3@example.com',
      password: 'password123'
    });
    
    if (!loginRes || loginRes.status !== 200) {
      console.log('Login failed');
      return;
    }
    
    console.log('✅ Login successful');
    
    // Check what cookies we received
    console.log('\n2. Checking cookies...');
    console.log('Cookies received:', Object.keys(cookies));
    
    // Check database state
    const user = await prisma.user.findUnique({
      where: { email: 'test3@example.com' },
      select: { 
        refreshTokenVersion: true,
        refreshTokenHash: true,
        refreshTokenIssuedAt: true
      }
    });
    
    console.log('\n3. Database state:');
    console.log(`   JTI: ${user?.refreshTokenVersion?.substring(0, 30)}...`);
    console.log(`   JTI length: ${user?.refreshTokenVersion?.length}`);
    console.log(`   Hash exists: ${!!user?.refreshTokenHash}`);
    console.log(`   Issued at: ${user?.refreshTokenIssuedAt?.toISOString()}`);
    
    // Try to manually verify the refresh token flow
    console.log('\n4. Checking refresh token requirements...');
    
    // Check if refresh endpoint expects specific headers
    console.log('Trying refresh with different approaches...');
    
    // Approach 1: With empty JSON body (what we tried)
    console.log('\n   Approach 1: Empty JSON body');
    const refresh1 = await makeRequest('post', '/auth/refresh', {});
    console.log(`   Status: ${refresh1?.status}, Message: ${refresh1?.data?.message}`);
    
    // Approach 2: With explicit refresh token in body
    console.log('\n   Approach 2: Looking for refresh token in cookies...');
    console.log('   Available cookies:', cookies);
    
    // Check if we need to extract refresh token from cookie
    const refreshTokenCookie = cookies['refresh_token'];
    if (refreshTokenCookie) {
      console.log(`   Found refresh_token cookie (first 20 chars): ${refreshTokenCookie.substring(0, 20)}...`);
      
      // Approach 3: Try with refresh token in body
      const refresh2 = await makeRequest('post', '/auth/refresh', {
        refreshToken: refreshTokenCookie
      });
      console.log(`   Status: ${refresh2?.status}, Message: ${refresh2?.data?.message}`);
    } else {
      console.log('   No refresh_token cookie found!');
      console.log('   Checking cookie names...');
      console.log('   All cookies:', cookies);
    }
    
    // Check the actual auth controller to see what it expects
    console.log('\n5. Checking server logs for clues...');
    console.log('   (Look for "refresh" or "token" in running server logs)');
    
    // Also check if refresh endpoint is CSRF protected
    console.log('\n6. CSRF consideration:');
    console.log('   Refresh endpoint may require CSRF header');
    console.log('   Check if /auth/refresh needs X-CSRF-Token header');
    
  } catch (error) {
    console.error('Debug failed:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

debugRefresh();
