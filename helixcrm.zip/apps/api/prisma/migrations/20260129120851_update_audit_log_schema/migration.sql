-- First, add new columns (nullable initially)
ALTER TABLE "audit_logs" ADD COLUMN IF NOT EXISTS "actorEmail" TEXT;
ALTER TABLE "audit_logs" ADD COLUMN IF NOT EXISTS "actorUserId" TEXT;
ALTER TABLE "audit_logs" ADD COLUMN IF NOT EXISTS "entityType" TEXT;
ALTER TABLE "audit_logs" ADD COLUMN IF NOT EXISTS "metadata" JSONB;
ALTER TABLE "audit_logs" ADD COLUMN IF NOT EXISTS "updatedAt" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP;

-- Create enums if they don't exist
DO $$ BEGIN
    CREATE TYPE "ActorType" AS ENUM ('USER', 'SYSTEM');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE "AuditSeverity" AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE "AuditAction" AS ENUM ('LOGIN_SUCCESS', 'LOGIN_FAILURE', 'LOGOUT', 'PASSWORD_CHANGE', 'TOKEN_REFRESH', 'USER_CREATED', 'USER_UPDATED', 'USER_DELETED', 'ROLE_CHANGED', 'CONTACT_CREATED', 'CONTACT_UPDATED', 'CONTACT_DELETED', 'DEAL_CREATED', 'DEAL_UPDATED', 'DEAL_DELETED', 'PIPELINE_CREATED', 'PIPELINE_UPDATED', 'PIPELINE_DELETED', 'LEAD_CREATED', 'LEAD_UPDATED', 'LEAD_DELETED', 'PERMISSION_DENIED', 'CSRF_FAILURE', 'RATE_LIMIT_TRIGGERED', 'SYSTEM_ERROR');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE "AuditEntityType" AS ENUM ('AUTH', 'USER', 'CONTACT', 'DEAL', 'PIPELINE', 'LEAD', 'ACCOUNT', 'ACTIVITY', 'SYSTEM');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Migrate data from old columns to new columns
-- 1. Copy userId to actorUserId
UPDATE "audit_logs" SET "actorUserId" = "userId" WHERE "actorUserId" IS NULL AND "userId" IS NOT NULL;

-- 2. Copy entity to entityType (convert to uppercase for enum)
UPDATE "audit_logs" SET "entityType" = UPPER("entity") WHERE "entityType" IS NULL AND "entity" IS NOT NULL;

-- 3. Set default actorEmail from users table (where possible)
UPDATE "audit_logs" al
SET "actorEmail" = u.email
FROM "users" u
WHERE al."actorUserId" = u.id AND al."actorEmail" IS NULL;

-- 4. For system actions, set actorEmail to 'system@helixcrm'
UPDATE "audit_logs" SET "actorEmail" = 'system@helixcrm' WHERE "actorEmail" IS NULL;

-- 5. Convert actorType to enum format
UPDATE "audit_logs" SET "actorType" = UPPER("actorType") WHERE "actorType" IS NOT NULL;

-- 6. Convert severity to enum format  
UPDATE "audit_logs" SET "severity" = UPPER("severity") WHERE "severity" IS NOT NULL;

-- Now alter columns to be non-nullable and use enums
-- First create temporary columns
ALTER TABLE "audit_logs" ADD COLUMN "action_new" "AuditAction";
ALTER TABLE "audit_logs" ADD COLUMN "entityType_new" "AuditEntityType";
ALTER TABLE "audit_logs" ADD COLUMN "severity_new" "AuditSeverity";
ALTER TABLE "audit_logs" ADD COLUMN "actorType_new" "ActorType";

-- Convert existing data (with fallbacks)
UPDATE "audit_logs" SET "action_new" = "action"::"AuditAction" WHERE "action" IS NOT NULL;
UPDATE "audit_logs" SET "entityType_new" = COALESCE("entityType"::"AuditEntityType", 'SYSTEM'::"AuditEntityType");
UPDATE "audit_logs" SET "severity_new" = COALESCE("severity"::"AuditSeverity", 'LOW'::"AuditSeverity");
UPDATE "audit_logs" SET "actorType_new" = COALESCE("actorType"::"ActorType", 'USER'::"ActorType");

-- Drop old columns and rename new ones
ALTER TABLE "audit_logs" DROP COLUMN "action";
ALTER TABLE "audit_logs" RENAME COLUMN "action_new" TO "action";

ALTER TABLE "audit_logs" DROP COLUMN "entityType";
ALTER TABLE "audit_logs" RENAME COLUMN "entityType_new" TO "entityType";

ALTER TABLE "audit_logs" DROP COLUMN "severity";
ALTER TABLE "audit_logs" RENAME COLUMN "severity_new" TO "severity";

ALTER TABLE "audit_logs" DROP COLUMN "actorType";
ALTER TABLE "audit_logs" RENAME COLUMN "actorType_new" TO "actorType";

-- Make columns NOT NULL
ALTER TABLE "audit_logs" ALTER COLUMN "actorEmail" SET NOT NULL;
ALTER TABLE "audit_logs" ALTER COLUMN "entityType" SET NOT NULL;
ALTER TABLE "audit_logs" ALTER COLUMN "action" SET NOT NULL;
ALTER TABLE "audit_logs" ALTER COLUMN "severity" SET NOT NULL;
ALTER TABLE "audit_logs" ALTER COLUMN "actorType" SET NOT NULL;

-- Update indexes
DROP INDEX IF EXISTS "audit_logs_severity_idx";
DROP INDEX IF EXISTS "audit_logs_actorType_createdAt_idx";
DROP INDEX IF EXISTS "audit_logs_requestId_idx";

CREATE INDEX IF NOT EXISTS "audit_logs_severity_idx" ON "audit_logs"("severity");
CREATE INDEX IF NOT EXISTS "audit_logs_actorType_createdAt_idx" ON "audit_logs"("actorType", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "audit_logs_requestId_idx" ON "audit_logs"("requestId");
CREATE INDEX IF NOT EXISTS "audit_logs_organizationId_createdAt_idx" ON "audit_logs"("organizationId", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "audit_logs_actorUserId_idx" ON "audit_logs"("actorUserId");

-- Add foreign key constraint
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_actorUserId_fkey" 
FOREIGN KEY ("actorUserId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
