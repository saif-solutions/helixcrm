// D:\Projects-In-Hand\helixcrm\apps\web\src\components\atoms\Select\SelectContext.tsx
import * as React from 'react';
import { SelectOption, SelectVariant, SelectSize, SelectValue } from './Select.types';

export interface SelectContextType {
  variant: SelectVariant;
  size: SelectSize;
  disabled: boolean;
  multiple: boolean;
  selectedValues: string[];
  onChange: (value: SelectValue) => void; // Changed to match SelectProps
  ariaExpanded: boolean;
  ariaControls: string;
  ariaActiveDescendant?: string;
  getOptionTestId: (option: SelectOption) => string;
}

const SelectContext = React.createContext<SelectContextType | null>(null);

export const useSelect = (): SelectContextType => {
  const context = React.useContext(SelectContext);
  if (!context) {
    throw new Error('useSelect must be used within a Select component');
  }
  return context;
};

export const SelectProvider = SelectContext.Provider;