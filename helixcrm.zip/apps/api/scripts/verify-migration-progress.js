// apps/api/scripts/verify-migration-progress.js
const fs = require('fs');
const path = require('path');

console.log('📊 Tenant Isolation Migration Progress');
console.log('======================================\n');

// Helper to read file
function readFile(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (error) {
    return '';
  }
}

// Check modules
const modules = [
  { name: 'Users', service: 'users.service.ts', controller: 'users.controller.ts', repo: 'users/repositories/user.repository.ts' },
  { name: 'Contacts', service: 'contacts.service.ts', controller: 'contacts.controller.ts', repo: 'contacts/repositories/contact.repository.ts' },
];

console.log('✅ MIGRATED MODULES:');
console.log('-------------------');

modules.forEach(module => {
  const servicePath = `./src/modules/${module.service}`;
  const controllerPath = `./src/modules/${module.controller}`;
  const repoPath = `./src/modules/${module.repo}`;
  
  const serviceContent = readFile(servicePath);
  const controllerContent = readFile(controllerPath);
  const repoContent = readFile(repoPath);
  
  const hasService = !!serviceContent;
  const hasController = !!controllerContent;
  const hasRepo = !!repoContent;
  
  const usesTenantContext = !serviceContent.includes('organizationId: string');
  const controllerMatches = !controllerContent.includes('organizationId,');
  const hasRepository = repoContent.includes('extends TenantAwareRepository');
  
  if (hasService && hasController && usesTenantContext && controllerMatches) {
    console.log(`   ${module.name}:`);
    console.log(`     ✅ Service uses tenant context`);
    console.log(`     ✅ Controller matches service`);
    if (hasRepo && hasRepository) {
      console.log(`     ✅ Has TenantAwareRepository`);
    } else {
      console.log(`     ⚠️  Missing or invalid repository`);
    }
  }
});

// Check remaining services needing migration
console.log('\n📋 REMAINING TO MIGRATE:');
console.log('------------------------');

const srcDir = './src/modules';
const serviceFiles = [];

function scanDir(dir) {
  const items = fs.readdirSync(dir, { withFileTypes: true });
  for (const item of items) {
    const fullPath = path.join(dir, item.name);
    if (item.isDirectory()) {
      scanDir(fullPath);
    } else if (item.name.endsWith('.service.ts')) {
      serviceFiles.push(fullPath);
    }
  }
}

try {
  scanDir(srcDir);
  
  const migrated = ['users.service.ts', 'contacts.service.ts'];
  const remaining = [];
  
  for (const file of serviceFiles) {
    const fileName = path.basename(file);
    if (!migrated.includes(fileName)) {
      const content = readFile(file);
      if (content.includes('organizationId: string')) {
        remaining.push({
          name: fileName,
          path: file,
          lineCount: content.split('\n').length,
          priority: getPriority(fileName)
        });
      }
    }
  }
  
  // Sort by priority
  remaining.sort((a, b) => b.priority - a.priority);
  
  console.log(`   ${remaining.length} services need migration:`);
  remaining.forEach(service => {
    console.log(`     ${service.priority === 3 ? '🔴' : service.priority === 2 ? '🟡' : '🔵'} ${service.name}`);
  });
  
  console.log('\n🎯 RECOMMENDED ORDER:');
  console.log('   1. Deals (business critical)');
  console.log('   2. Leads (sales pipeline)');
  console.log('   3. Analytics (many orgId params)');
  console.log('   4. Others');
  
} catch (error) {
  console.log('   ⚠️  Could not scan services');
}

function getPriority(fileName) {
  const highPriority = ['deals.service.ts', 'leads.service.ts'];
  const mediumPriority = ['analytics.service.ts', 'analytics-summary.service.ts'];
  
  if (highPriority.includes(fileName)) return 3;
  if (mediumPriority.includes(fileName)) return 2;
  return 1;
}

console.log('\n======================================');
console.log('✅ Phase 2 Progress: 2/15 modules migrated (13%)');
console.log('🎯 Next: Deals Service');