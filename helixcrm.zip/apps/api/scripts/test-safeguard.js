// apps/api/scripts/test-safeguard.js
const { PrismaClient } = require('@prisma/client');

async function testSafeguard() {
  console.log('🔒 Testing Prisma Hard Fail Safeguard\n');
  
  const prisma = new PrismaClient();
  
  try {
    await prisma.$connect();
    console.log('✅ Connected to database');
    
    // Test 1: Unsafe query without organizationId
    console.log('\n🔴 Test 1: findMany without organizationId');
    try {
      const users = await prisma.user.findMany({
        where: { email: { contains: 'test' } }
      });
      console.log('❌ FAILED: Returned', users.length, 'users (DATA LEAK!)');
      return false;
    } catch (error) {
      if (error.message.includes('SECURITY VIOLATION')) {
        console.log('✅ PASSED: Safeguard blocked the query');
      } else {
        console.log('⚠️ Unexpected error:', error.message);
        return false;
      }
    }
    
    // Test 2: Safe query with organizationId
    console.log('\n🟢 Test 2: findMany WITH organizationId');
    const org = await prisma.organization.findFirst();
    if (org) {
      try {
        const users = await prisma.user.findMany({
          where: { organizationId: org.id }
        });
        console.log('✅ PASSED: Returned', users.length, 'users from org', org.name);
      } catch (error) {
        console.log('❌ FAILED:', error.message);
        return false;
      }
    } else {
      console.log('⚠️ No organizations found');
    }
    
    // Test 3: updateMany without organizationId
    console.log('\n🔴 Test 3: updateMany without organizationId');
    try {
      await prisma.user.updateMany({
        where: { isActive: true },
        data: { lastLoginAt: new Date() }
      });
      console.log('❌ FAILED: updateMany succeeded (DATA LEAK!)');
      return false;
    } catch (error) {
      if (error.message.includes('SECURITY VIOLATION')) {
        console.log('✅ PASSED: Safeguard blocked updateMany');
      } else {
        console.log('⚠️ Unexpected error:', error.message);
        return false;
      }
    }
    
    console.log('\n🎉 All security tests passed!');
    console.log('✅ Tenant isolation is enforced');
    console.log('✅ Data leaks are prevented');
    
    return true;
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    return false;
  } finally {
    await prisma.$disconnect();
  }
}

// Run test
testSafeguard().then(success => {
  process.exit(success ? 0 : 1);
});