const fs = require('fs');
const path = require('path');

const schemaPath = path.join(__dirname, 'prisma/schema.prisma');
let schema = fs.readFileSync(schemaPath, 'utf8');

// Update DealDailySummary model with @map annotations
const dealDailySummaryUpdate = `model DealDailySummary {
  id              String      @id @default(uuid())
  organizationId  String      @map("organization_id")
  date            DateTime    @map("date")

  // Counts
  totalDeals      Int         @default(0) @map("total_deals")
  wonDeals        Int         @default(0) @map("won_deals")
  lostDeals       Int         @default(0) @map("lost_deals")
  openDeals       Int         @default(0) @map("open_deals")

  // Amounts
  totalAmount     Decimal     @db.Decimal(15, 2) @map("total_amount")
  wonAmount       Decimal     @db.Decimal(15, 2) @map("won_amount")
  averageDealSize Decimal     @db.Decimal(15, 2) @map("average_deal_size")

  // Derived metrics
  winRate         Decimal     @db.Decimal(5, 2) @map("win_rate")

  // Metadata
  currency        String      @default("USD") @map("currency")
  pipelineId      String?     @map("pipeline_id")
  stageId         String?     @map("stage_id")

  // Timestamps
  createdAt       DateTime    @default(now()) @map("created_at")
  updatedAt       DateTime    @updatedAt @map("updated_at")
  summarizedAt    DateTime    @default(now()) @map("summarized_at")

  // Indexes for fast querying
  @@unique([organizationId, date, pipelineId, stageId, currency])
  @@index([organizationId, date])
  @@index([organizationId, date, pipelineId])
  @@index([organizationId, date, stageId])
  @@index([summarizedAt])
  @@map("deal_daily_summaries")
}`;

// Update RevenueDailySummary model
const revenueDailySummaryUpdate = `model RevenueDailySummary {
  id              String      @id @default(uuid())
  organizationId  String      @map("organization_id")
  date            DateTime    @map("date")

  // Revenue metrics
  totalRevenue    Decimal     @db.Decimal(15, 2) @map("total_revenue")
  wonRevenue      Decimal     @db.Decimal(15, 2) @map("won_revenue")
  forecastRevenue Decimal     @db.Decimal(15, 2) @map("forecast_revenue")

  // Counts
  totalDeals      Int         @default(0) @map("total_deals")
  wonDeals        Int         @default(0) @map("won_deals")

  // Derived metrics
  averageDealSize Decimal     @db.Decimal(15, 2) @map("average_deal_size")

  // Currency
  currency        String      @default("USD") @map("currency")

  // Timestamps
  createdAt       DateTime    @default(now()) @map("created_at")
  updatedAt       DateTime    @updatedAt @map("updated_at")
  summarizedAt    DateTime    @default(now()) @map("summarized_at")

  // Indexes
  @@unique([organizationId, date, currency])
  @@index([organizationId, date])
  @@index([summarizedAt])
  @@map("revenue_daily_summaries")
}`;

// Update PipelineStageSummary model
const pipelineStageSummaryUpdate = `model PipelineStageSummary {
  id              String      @id @default(uuid())
  organizationId  String      @map("organization_id")
  pipelineId      String      @map("pipeline_id")
  stageId         String      @map("stage_id")
  date            DateTime    @map("date")

  // Stage metrics
  dealCount       Int         @default(0) @map("deal_count")
  totalAmount     Decimal     @db.Decimal(15, 2) @map("total_amount")
  averageAmount   Decimal     @db.Decimal(15, 2) @map("average_amount")

  // Duration metrics (days)
  avgStageDuration Int        @default(0) @map("avg_stage_duration")
  maxStageDuration Int        @default(0) @map("max_stage_duration")

  // Bottleneck indicator
  isBottleneck    Boolean     @default(false) @map("is_bottleneck")

  // Timestamps
  createdAt       DateTime    @default(now()) @map("created_at")
  updatedAt       DateTime    @updatedAt @map("updated_at")
  summarizedAt    DateTime    @default(now()) @map("summarized_at")

  // Indexes
  @@unique([organizationId, pipelineId, stageId, date])
  @@index([organizationId, date])
  @@index([pipelineId, stageId])
  @@index([isBottleneck])
  @@map("pipeline_stage_summaries")
}`;

// Update ActivityDailySummary model
const activityDailySummaryUpdate = `model ActivityDailySummary {
  id              String      @id @default(uuid())
  organizationId  String      @map("organization_id")
  date            DateTime    @map("date")

  // Activity counts by type
  loginCount      Int         @default(0) @map("login_count")
  dealCreated     Int         @default(0) @map("deal_created")
  dealUpdated     Int         @default(0) @map("deal_updated")
  dealWon         Int         @default(0) @map("deal_won")
  dealLost        Int         @default(0) @map("deal_lost")
  contactCreated  Int         @default(0) @map("contact_created")
  contactUpdated  Int         @default(0) @map("contact_updated")
  leadCreated     Int         @default(0) @map("lead_created")
  leadConverted   Int         @default(0) @map("lead_converted")

  // User activity
  activeUsers     Int         @default(0) @map("active_users")
  totalActions    Int         @default(0) @map("total_actions")

  // Timestamps
  createdAt       DateTime    @default(now()) @map("created_at")
  updatedAt       DateTime    @updatedAt @map("updated_at")
  summarizedAt    DateTime    @default(now()) @map("summarized_at")

  // Indexes
  @@unique([organizationId, date])
  @@index([organizationId, date])
  @@index([summarizedAt])
  @@map("activity_daily_summaries")
}`;

// Replace the models in the schema
function replaceModel(schema, modelName, newModel) {
  const startPattern = `model ${modelName} {`;
  const endPattern = `}`;
  
  let inModel = false;
  let depth = 0;
  const lines = schema.split('\n');
  const newLines = [];
  
  for (const line of lines) {
    if (line.trim().startsWith(startPattern)) {
      inModel = true;
      depth = 0;
      // Add the new model
      newLines.push(newModel);
      continue;
    }
    
    if (!inModel) {
      newLines.push(line);
      continue;
    }
    
    // Track depth within the model
    if (line.includes('{')) depth++;
    if (line.includes('}')) {
      if (depth === 0) {
        inModel = false;
      } else {
        depth--;
      }
    }
  }
  
  return newLines.join('\n');
}

// Apply all updates
schema = replaceModel(schema, 'DealDailySummary', dealDailySummaryUpdate);
schema = replaceModel(schema, 'RevenueDailySummary', revenueDailySummaryUpdate);
schema = replaceModel(schema, 'PipelineStageSummary', pipelineStageSummaryUpdate);
schema = replaceModel(schema, 'ActivityDailySummary', activityDailySummaryUpdate);

// Write the updated schema
fs.writeFileSync(schemaPath, schema);
console.log('✅ Updated Prisma schema with explicit @map annotations');
