const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');
const prisma = new PrismaClient();

async function fixPassword() {
  try {
    const email = 'test3@example.com';
    
    // Check current user
    const user = await prisma.user.findUnique({
      where: { email },
      select: { id: true, passwordHash: true }
    });
    
    if (!user) {
      console.log(`User ${email} not found`);
      return;
    }
    
    console.log(`Current hash for ${email}:`);
    console.log(`  ${user.passwordHash?.substring(0, 60)}...`);
    
    // Try to validate with common test passwords
    const testPasswords = [
      'password123',
      'Password123!',
      'password',
      'test123',
      'Test123!'
    ];
    
    console.log('\nTesting common passwords...');
    let found = false;
    
    for (const password of testPasswords) {
      if (user.passwordHash && await bcrypt.compare(password, user.passwordHash)) {
        console.log(`✅ Password found: "${password}"`);
        found = true;
        break;
      }
    }
    
    if (!found) {
      console.log('❌ No matching password found');
      console.log('\nSetting new password...');
      
      const newPassword = 'TestPassword123!';
      const newHash = await bcrypt.hash(newPassword, 10);
      
      await prisma.user.update({
        where: { email },
        data: { passwordHash: newHash }
      });
      
      console.log(`✅ New password set: "${newPassword}"`);
      console.log(`New hash: ${newHash.substring(0, 30)}...`);
    }
    
  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

fixPassword();
