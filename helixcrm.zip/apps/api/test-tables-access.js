const { PrismaClient } = require('@prisma/client');

async function testTableAccess() {
  console.log('Testing access to analytics summary tables...\n');
  
  const prisma = new PrismaClient();
  
  try {
    // Test 1: Count records in each table
    console.log('1. Counting records in new tables:');
    
    const [dealCount, revenueCount, pipelineCount, activityCount] = await Promise.all([
      prisma.dealDailySummary.count(),
      prisma.revenueDailySummary.count(),
      prisma.pipelineStageSummary.count(),
      prisma.activityDailySummary.count(),
    ]);
    
    console.log(`   - deal_daily_summaries: ${dealCount} records`);
    console.log(`   - revenue_daily_summaries: ${revenueCount} records`);
    console.log(`   - pipeline_stage_summaries: ${pipelineCount} records`);
    console.log(`   - activity_daily_summaries: ${activityCount} records`);
    
    // Test 2: Create a test record
    console.log('\n2. Testing create operation:');
    
    const org = await prisma.organization.findFirst();
    if (org) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const testRecord = await prisma.dealDailySummary.create({
        data: {
          organizationId: org.id,
          date: today,
          totalDeals: 10,
          wonDeals: 5,
          lostDeals: 2,
          openDeals: 3,
          totalAmount: 100000,
          wonAmount: 50000,
          averageDealSize: 10000,
          winRate: 50,
          currency: 'USD',
          pipelineId: null,
          stageId: null,
        },
      });
      
      console.log(`   ✅ Created test record with ID: ${testRecord.id}`);
      
      // Test 3: Read the record
      const foundRecord = await prisma.dealDailySummary.findUnique({
        where: { id: testRecord.id },
      });
      
      console.log(`   ✅ Read record: ${foundRecord ? 'Success' : 'Failed'}`);
      
      // Test 4: Update the record
      const updatedRecord = await prisma.dealDailySummary.update({
        where: { id: testRecord.id },
        data: { totalDeals: 15 },
      });
      
      console.log(`   ✅ Updated record: totalDeals = ${updatedRecord.totalDeals}`);
      
      // Test 5: Delete the record
      await prisma.dealDailySummary.delete({
        where: { id: testRecord.id },
      });
      
      console.log(`   ✅ Deleted test record`);
    } else {
      console.log('   ⚠️ No organization found for testing');
    }
    
    console.log('\n✅ All CRUD operations work correctly!');
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

testTableAccess();
