// apps/api/src/shared/prisma/prisma.module.ts
import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { PrismaSafeguardService } from './prisma-safeguard.service';

@Global()
@Module({
  providers: [PrismaService, PrismaSafeguardService],
  exports: [PrismaService],
})
export class PrismaModule {}