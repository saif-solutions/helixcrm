// apps/api/src/shared/filters/security-exception.filter.ts
import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';

// Define the error class here since module doesn't exist yet
export class TenantIsolationViolationError extends Error {
  constructor(message: string) {
    super(`SECURITY VIOLATION: ${message}`);
    this.name = 'TenantIsolationViolationError';
  }
}

@Catch()
export class SecurityExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(SecurityExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    const status =
      exception instanceof HttpException
        ? exception.getStatus()
        : exception instanceof TenantIsolationViolationError
        ? HttpStatus.FORBIDDEN
        : HttpStatus.INTERNAL_SERVER_ERROR;

    const errorResponse = this.buildErrorResponse(exception, request, status);
    this.logError(exception, request, status);

    response.status(status).json(errorResponse);
  }

  private buildErrorResponse(exception: any, request: Request, status: number) {
    const errorResponse: any = {
      success: false,
      timestamp: new Date().toISOString(),
      path: request.url,
      method: request.method,
      statusCode: status,
    };

    if (exception instanceof TenantIsolationViolationError) {
      errorResponse.message = 'Security policy violation';
      errorResponse.error = 'FORBIDDEN';
      errorResponse.details = {
        reason: 'Tenant isolation violation',
        code: 'TENANT_ISOLATION_VIOLATION',
      };
      
      if (process.env.NODE_ENV === 'production') {
        errorResponse.details.internalMessage = 'Contact system administrator';
      } else {
        errorResponse.details.internalMessage = exception.message;
      }
    }
    else if (exception instanceof HttpException) {
      const response = exception.getResponse();
      
      if (typeof response === 'string') {
        errorResponse.message = response;
      } else if (typeof response === 'object') {
        Object.assign(errorResponse, response);
      }
      
      errorResponse.error = this.getHttpStatusText(status);
    }
    else {
      errorResponse.message = 'Internal server error';
      errorResponse.error = 'INTERNAL_SERVER_ERROR';
      
      if (process.env.NODE_ENV !== 'production') {
        errorResponse.details = {
          message: exception instanceof Error ? exception.message : 'Unknown error',
        };
      } else {
        errorResponse.details = {
          reference: `ERR-${Date.now()}`,
        };
      }
    }

    return errorResponse;
  }

  private logError(exception: any, request: Request, status: number) {
    const logMessage = `${request.method} ${request.url} ${status}`;
    
    if (exception instanceof TenantIsolationViolationError) {
      this.logger.error(`SECURITY VIOLATION: ${logMessage} - ${exception.message}`);
    }
    else if (status >= 500) {
      this.logger.error(`SERVER ERROR: ${logMessage}`, exception);
    }
    else if (status >= 400) {
      this.logger.warn(`CLIENT ERROR: ${logMessage} - ${exception.message}`);
    }
  }

  private getHttpStatusText(status: number): string {
    const statusTexts: Record<number, string> = {
      400: 'BAD_REQUEST',
      401: 'UNAUTHORIZED',
      403: 'FORBIDDEN',
      404: 'NOT_FOUND',
      500: 'INTERNAL_SERVER_ERROR',
    };
    
    return statusTexts[status] || 'UNKNOWN_ERROR';
  }
}