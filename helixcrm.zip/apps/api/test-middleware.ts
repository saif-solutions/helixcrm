// apps/api/test-middleware.ts
import { PrismaService } from './src/shared/prisma/prisma.service';

async function testMiddleware() {
  console.log('🧪 Testing if Prisma middleware is called...\n');
  
  const prisma = new PrismaService();
  
  try {
    // This will trigger onModuleInit
    await prisma.$connect();
    
    console.log('\n🧪 Making test query...');
    
    // This should show middleware logs
    const result = await prisma.user.findMany({
      where: { email: { contains: 'test' } }
    });
    
    console.log(`❌ Query succeeded without middleware logs!`);
    console.log(`   Middleware is NOT working`);
    console.log(`   Returned ${result.length} users`);
    
  } catch (error: any) {
    console.log(`✅ Error (expected if middleware works):`, error.message);
  } finally {
    await prisma.$disconnect();
  }
}

testMiddleware();