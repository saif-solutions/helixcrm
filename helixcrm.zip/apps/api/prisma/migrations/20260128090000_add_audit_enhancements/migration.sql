-- Add new columns to audit_logs table if they don't exist
DO $$ 
BEGIN
    -- Add actorType column if not exists
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'audit_logs' AND column_name = 'actorType') THEN
        ALTER TABLE "audit_logs" ADD COLUMN "actorType" VARCHAR(20) DEFAULT 'user';
    END IF;

    -- Add severity column if not exists (note: severity might already exist from previous migration)
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'audit_logs' AND column_name = 'severity') THEN
        ALTER TABLE "audit_logs" ADD COLUMN "severity" VARCHAR(20) DEFAULT 'LOW';
    END IF;

    -- Add requestId column if not exists
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'audit_logs' AND column_name = 'requestId') THEN
        ALTER TABLE "audit_logs" ADD COLUMN "requestId" VARCHAR(255);
    END IF;
END $$;

-- Create indexes if they don't exist
CREATE INDEX IF NOT EXISTS "audit_logs_severity_idx" ON "audit_logs"("severity");
CREATE INDEX IF NOT EXISTS "audit_logs_actorType_createdAt_idx" ON "audit_logs"("actorType", "createdAt" DESC);
CREATE INDEX IF NOT EXISTS "audit_logs_requestId_idx" ON "audit_logs"("requestId");

-- Update existing records
UPDATE "audit_logs" SET "actorType" = 'user' WHERE "actorType" IS NULL;
UPDATE "audit_logs" SET "severity" = 'LOW' WHERE "severity" IS NULL;
