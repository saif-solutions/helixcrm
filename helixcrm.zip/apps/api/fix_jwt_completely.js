const fs = require('fs');
const path = require('path');

const filePath = path.resolve(__dirname, 'src/modules/auth/auth.service.ts');
let content = fs.readFileSync(filePath, 'utf8');

console.log('=== FIXING JWT PAYLOAD ISSUES ===');

// Fix 1: login method - replace the entire access token generation section
const loginFix = `      // CORRECT: Map our domain user to JwtPayload
      const jwtPayload = {
        sub: user.id,                    // userId → sub
        org: user.organizationId,        // organizationId → org
        role: roles.includes('SystemAdmin') ? 'admin' : 'user', // Determine role from roles
        version: user.tokenVersion,      // tokenVersion → version
      };

      // Use auth-core JWT service CORRECTLY
      const accessToken = this.authCoreAdapter.jwt.issueToken(jwtPayload);

      // IMPORTANT: Let auth-core generate refresh token with its own jti
      const refreshToken = await this.authCoreAdapter.tokenManager.issueRefreshToken(
        user.id,
        user.organizationId,
      );`;

content = content.replace(
  /\/\/ Use auth-core token manager service for access token[\s\S]*?const refreshToken = await this\.authCoreAdapter\.tokenManager\.issueRefreshToken\(\{[^}]+\}\);/,
  loginFix
);

// Fix 2: refreshToken method - fix the new access token generation
const refreshTokenFix = `          // CORRECT: Map for new JWT
          const newJwtPayload = {
            sub: userWithOrg.id,
            org: userWithOrg.organizationId,
            role: roles.includes('SystemAdmin') ? 'admin' : 'user',
            version: userWithOrg.tokenVersion + 1,
          };

          // Generate new access token
          const newAccessToken = this.authCoreAdapter.jwt.issueToken(newJwtPayload);

          // Generate new refresh token (auth-core will create new jti)
          const newRefreshToken = await this.authCoreAdapter.tokenManager.issueRefreshToken(
            userWithOrg.id,
            userWithOrg.organizationId,
          );`;

content = content.replace(
  /\/\/ Generate new refresh token[\s\S]*?const newAccessToken = await this\.authCoreAdapter\.tokenManager\.issueAccessToken\(\{[\s\S]*?\}\);/,
  refreshTokenFix
);

// Fix 3: Remove any remaining userId/email/organizationId from JWT calls
content = content.replace(/\.issueToken\(\{\s*userId:/g, '.issueToken({ sub:');
content = content.replace(/\.issueToken\(\{\s*sub: ([^,]+),\s*email:/g, '.issueToken({ sub: $1,');
content = content.replace(/organizationId:/g, 'org:');
content = content.replace(/tokenVersion:/g, 'version:');

// Remove properties that don't belong in JWT payload
content = content.replace(/,\s*permissions: [^,]+,/g, ',');
content = content.replace(/,\s*roles: [^,]+,/g, ',');
content = content.replace(/,\s*metadata: [^}]+\}/g, '}');

fs.writeFileSync(filePath, content, 'utf8');
console.log('✅ JWT payloads completely fixed');
console.log('All JWT calls now use correct JwtPayload contract');
