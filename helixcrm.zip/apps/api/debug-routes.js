const http = require('http');

console.log('🔍 Debugging Route Configuration\n');

const baseURL = 'http://localhost:3001';
const paths = [
  '/',
  '/api',
  '/api/v1',
  '/api/v1/auth',
  '/api/v1/auth/register',
  '/api/v1/auth/login',
  '/health',
  '/api/health',
  '/api/v1/health'
];

function testPath(path) {
  return new Promise((resolve) => {
    const req = http.request(baseURL + path, { method: 'GET', timeout: 3000 }, (res) => {
      console.log(`   ${path.padEnd(25)} → HTTP ${res.statusCode}`);
      resolve({ path, status: res.statusCode });
    });

    req.on('error', (err) => {
      console.log(`   ${path.padEnd(25)} → ERROR: ${err.code || err.message}`);
      resolve({ path, error: err.message });
    });

    req.on('timeout', () => {
      console.log(`   ${path.padEnd(25)} → TIMEOUT`);
      req.destroy();
      resolve({ path, timeout: true });
    });

    req.end();
  });
}

async function runDiagnostic() {
  console.log('Testing various paths (timeout after 3s):\n');
  
  for (const path of paths) {
    await testPath(path);
  }
  
  console.log('\n' + '='.repeat(60));
  console.log('ANALYSIS:');
  console.log('• 404 = Path exists but no route handler');
  console.log('• Timeout = Path not recognized by server');
  console.log('• 200/201 = Success');
  console.log('='.repeat(60));
}

runDiagnostic().catch(console.error);