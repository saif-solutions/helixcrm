console.log('��� Testing Audit Integrity Basic Setup...');
console.log('=========================================\n');

const fs = require('fs');
const path = require('path');

const checks = [
  {
    name: 'Migration file exists',
    path: 'prisma/migrations/20260204_000001_create_append_only_audit_tables/migration.sql',
    check: (p) => fs.existsSync(p)
  },
  {
    name: 'Prisma schema updated',
    path: 'prisma/schema.prisma',
    check: (p) => {
      if (!fs.existsSync(p)) return false;
      const content = fs.readFileSync(p, 'utf8');
      return content.includes('AppendOnlyAuditChain') && content.includes('AuditIntegrityVerification');
    }
  },
  {
    name: 'AuditIntegrityService exists',
    path: 'src/shared/audit-integrity/audit-integrity.service.ts',
    check: (p) => fs.existsSync(p)
  },
  {
    name: 'DailyVerificationJob exists',
    path: 'src/shared/audit-integrity/jobs/daily-verification.job.ts',
    check: (p) => fs.existsSync(p)
  },
  {
    name: 'AppModule includes AuditIntegrityModule',
    path: 'src/app.module.ts',
    check: (p) => {
      if (!fs.existsSync(p)) return false;
      const content = fs.readFileSync(p, 'utf8');
      return content.includes('AuditIntegrityModule');
    }
  }
];

let allPassed = true;

checks.forEach((check, index) => {
  const fullPath = path.join(__dirname, check.path);
  const passed = check.check(fullPath);
  
  console.log(`${index + 1}. ${check.name}: ${passed ? '✅' : '❌'}`);
  if (!passed) {
    console.log(`   Path: ${fullPath}`);
    allPassed = false;
  }
});

console.log('\n' + '='.repeat(50));
if (allPassed) {
  console.log('✅ All checks passed!');
  console.log('\nNext steps:');
  console.log('1. Run migration: npx prisma migrate deploy');
  console.log('2. Generate Prisma client: npx prisma generate');
  console.log('3. Test the service manually');
} else {
  console.log('❌ Some checks failed. Please fix the issues above.');
  process.exit(1);
}
