const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function debugPassword() {
  try {
    const user = await prisma.user.findUnique({
      where: { email: 'admin@acme.com' },
      select: { 
        email: true,
        passwordHash: true,
        organizationId: true 
      }
    });
    
    if (!user) {
      console.log('❌ User not found');
      return;
    }
    
    console.log('User details:');
    console.log(`  Email: ${user.email}`);
    console.log(`  Organization ID: ${user.organizationId}`);
    console.log(`  Password hash: ${user.passwordHash}`);
    console.log(`  Hash length: ${user.passwordHash?.length}`);
    console.log(`  Hash prefix: ${user.passwordHash?.substring(0, 30)}...`);
    
    // Check hash format
    if (user.passwordHash?.startsWith('$2b$')) {
      console.log('\n✅ Password hash appears to be valid bcrypt format');
    } else {
      console.log('\n⚠️  Password hash may not be bcrypt format');
    }
    
    // Let's also check what auth-core expects
    console.log('\nNote: Auth-core may use different hashing algorithm');
    console.log('Try using the seed script to create a fresh test user...');
    
  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

debugPassword();
