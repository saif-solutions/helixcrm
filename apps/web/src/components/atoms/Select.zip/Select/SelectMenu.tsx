// D:\Projects-In-Hand\helixcrm\apps\web\src\components\atoms\Select\SelectMenu.tsx
import * as React from 'react';
import { 
  SelectOption, 
  isOptionSelected, 
  groupOptions,
} from './Select.types';
import { 
  getMenuClasses, 
  getOptionClasses, 
  getOptionGroupClasses, 
  getSelectTestId,
  getVirtualizedStyles,
  getVirtualizedItemStyles,
  getItemHeightBySize,
  selectClasses,
} from './Select.styles';

interface SelectMenuProps {
  isOpen: boolean;
  options: SelectOption[];
  filteredOptions: SelectOption[];
  searchQuery: string;
  searchable: boolean;
  multiple: boolean;
  disabled: boolean;
  size: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  position: 'top' | 'bottom' | 'auto';
  maxMenuHeight: string | number;
  minMenuWidth: string | number;
  matchWidth: boolean;
  ungroupedLabel: string;
  enableVirtualization: boolean;
  virtualizationThreshold: number;
  selectedValue: string | number | string[];
  
  focusedIndex: number;
  testId: string;
  overscan: number;
  menuClassName?: string;
  optionClassName?: string;
  renderOption?: (option: SelectOption, state: { 
    isSelected: boolean; 
    isFocused: boolean; 
    isDisabled: boolean;
  }) => React.ReactNode;
  
  // Handlers
  onSearchChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onOptionClick: (option: SelectOption) => void;
  onOptionFocus: (index: number) => void;
  
  // Refs

  menuRef: React.RefObject<HTMLDivElement | null>;
  searchInputRef: React.RefObject<HTMLInputElement | null>;
}

export const SelectMenu = React.memo(({
  isOpen,
  options,
  filteredOptions,
  searchQuery,
  searchable,
  multiple,
  disabled,
  size,
  position,
  maxMenuHeight,
  minMenuWidth,
  matchWidth,
  ungroupedLabel,
  enableVirtualization,
  selectedValue,
  focusedIndex,
  testId,
  overscan,
  menuClassName,
  optionClassName,
  renderOption,
  onSearchChange,
  onOptionClick,
  onOptionFocus,
  menuRef,
  searchInputRef,
}: SelectMenuProps) => {
  
  const groupedOptions = React.useMemo(() => 
    groupOptions(filteredOptions, ungroupedLabel),
    [filteredOptions, ungroupedLabel]
  );
  
const renderDefaultOption = React.useCallback((option: SelectOption, index: number) => {
  const isSelected = isOptionSelected(option, selectedValue);
  const isFocused = focusedIndex === index;
  const isOptionDisabled = option.disabled || disabled;
  const optionId = `${testId}-option-${option.value}`;
  
  return (
    <div
      key={option.value}
      id={optionId}
      className={getOptionClasses(isSelected, isFocused, isOptionDisabled, optionClassName)}
      onClick={(e) => {
        e.stopPropagation(); // ADD THIS LINE
        !isOptionDisabled && onOptionClick(option);
      }}
      onMouseEnter={() => !isOptionDisabled && onOptionFocus(index)}
      role="option"
      aria-selected={isSelected}
      aria-disabled={isOptionDisabled}
      data-testid={getSelectTestId(testId, 'option', option.value)}
      data-value={option.value}
      style={enableVirtualization ? getVirtualizedItemStyles(index, getItemHeightBySize(size)) : undefined}
    >
      <div className={selectClasses.option.content}>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            {option.icon && (
              <span className={selectClasses.option.icon}>
                {option.icon}
              </span>
            )}
            <div>
              {/* Add aria-disabled to the label container as well */}
              <div 
                className={selectClasses.option.label}
                aria-disabled={isOptionDisabled}
              >
                {option.label}
              </div>
              {option.description && (
                <div className={selectClasses.option.description}>
                  {option.description}
                </div>
              )}
            </div>
          </div>
        </div>
        
        {multiple ? (
          <input
            type="checkbox"
            checked={isSelected}
            readOnly
            className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700"
            aria-label={`Select ${option.label}`}
            aria-disabled={isOptionDisabled}
            data-testid={`${testId}-checkbox-${option.value}`}
          />
        ) : (
          isSelected && (
            <svg 
              className={selectClasses.option.check} 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
              data-testid={`${testId}-check-${option.value}`}
              aria-disabled={isOptionDisabled}
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          )
        )}
      </div>
    </div>
  );
}, [selectedValue, focusedIndex, disabled, testId, optionClassName, enableVirtualization, size, onOptionClick, onOptionFocus]);


  const renderGroupedOptions = React.useMemo(() => {
    return groupedOptions.map((group, groupIndex) => {
      const isGroupDisabled = group.disabled || group.options.every(opt => opt.disabled);
      const groupId = `group-${group.label.replace(/\s+/g, '-').toLowerCase()}-${groupIndex}`;
      
      return (
        <React.Fragment key={groupId}>
          <div 
            id={groupId}
            className={getOptionGroupClasses(isGroupDisabled)}
            role="group"
            aria-label={group.ariaLabel}
            aria-labelledby={groupId}
            data-testid={`${testId}-group-${group.label.replace(/\s+/g, '-').toLowerCase()}`}
          >
            {group.label}
          </div>
          {group.options.map((option, _optionIndex) => {
            const absoluteIndex = filteredOptions.findIndex(opt => opt.value === option.value);
            const optionId = `${testId}-option-${option.value}`;
            
// Fix the renderOption cloning issue:
if (renderOption) {
  const renderedOption = renderOption(option, { 
    isSelected: isOptionSelected(option, selectedValue), 
    isFocused: focusedIndex === absoluteIndex,
    isDisabled: option.disabled || disabled 
  });
  
  // Wrap custom rendered option in a div with proper attributes
  return (
    <div
      key={option.value}
      id={optionId}
      data-testid={getSelectTestId(testId, 'option', option.value)}
      data-value={option.value}
      style={enableVirtualization ? getVirtualizedItemStyles(absoluteIndex, getItemHeightBySize(size)) : undefined}
    >
      {renderedOption}
    </div>
  );
}
            
            return renderDefaultOption(option, absoluteIndex);
          })}
        </React.Fragment>
      );
    });
  }, [groupedOptions, filteredOptions, selectedValue, focusedIndex, disabled, testId, renderOption, renderDefaultOption]);
  
  const renderSearchInput = searchable && isOpen ? (
    <div className={selectClasses.search.base}>
      <input
        ref={searchInputRef}
        type="text"
        value={searchQuery}
        onChange={onSearchChange}
        placeholder="Type to search..."
        className={selectClasses.search.input}
        autoComplete="off"
        autoCorrect="off"
        spellCheck="false"
        aria-label="Search options"
        aria-controls={`${testId}-menu`}
        data-testid={`${testId}-search`}
      />
    </div>
  ) : null;
  
  const VirtualizationWrapper = enableVirtualization 
    ? ({ children }: { children: React.ReactNode }) => (
        <div 
          style={getVirtualizedStyles(getItemHeightBySize(size), overscan, maxMenuHeight as string)}
          className="relative"
          role="listbox"
          aria-label="Options list"
        >
          {children}
        </div>
      )
    : ({ children }: { children: React.ReactNode }) => (
        <div 
          className="max-h-[250px] overflow-y-auto" 
          role="listbox"
          aria-label="Options list"
        >
          {children}
        </div>
      );
  
  if (!isOpen) return null;
  
  return (
    <div
      ref={menuRef}
      id={`${testId}-menu`}
      className={getMenuClasses(size, position, menuClassName)}
      style={{
        maxHeight: maxMenuHeight,
        minWidth: matchWidth ? '100%' : minMenuWidth,
        width: matchWidth ? '100%' : undefined,
        position: 'absolute',
        zIndex: 50,
        ...(position === 'top' ? { bottom: '100%', marginBottom: '0.25rem' } : { top: '100%', marginTop: '0.25rem' }),
      }}
      role="listbox"
      aria-multiselectable={multiple}
      aria-labelledby={isOpen ? `${testId}-label` : undefined}
      data-testid={getSelectTestId(testId, 'menu')}
      aria-busy={filteredOptions.length !== options.length ? 'true' : undefined}
    >
      {renderSearchInput}
      
      {filteredOptions.length === 0 ? (
        <div 
          className="px-4 py-3 text-sm text-gray-500 dark:text-gray-400 text-center"
          role="status"
          aria-live="polite"
          data-testid={`${testId}-empty`}
        >
          {searchQuery ? 'No matching options' : 'No options available'}
        </div>
      ) : (
        <VirtualizationWrapper>
          {renderGroupedOptions}
        </VirtualizationWrapper>
      )}
    </div>
  );
});

SelectMenu.displayName = 'SelectMenu';