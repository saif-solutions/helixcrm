// apps/api/src/test.controller.ts
import { Controller, Get } from '@nestjs/common';
import { PrismaService } from './shared/prisma/prisma.service';

@Controller('test')
export class TestController {
  constructor(private prisma: PrismaService) {}

  @Get('safeguard')
  async testSafeguard() {
    try {
      // This should throw TenantIsolationViolationError
      const users = await this.prisma.user.findMany({
        where: { email: { contains: 'test' } }
      });
      return { success: false, message: 'Safeguard failed!' };
    } catch (error) {
      return { 
        success: true, 
        message: 'Safeguard is working!',
        error: error.message 
      };
    }
  }
}